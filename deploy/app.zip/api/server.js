var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// backend/scripts/preview-server.ts
var import_node_http = __toESM(require("node:http"));
var import_node_url = require("node:url");

// backend/prisma/seed-data.ts
var resources = [
  { name: "Psychology Today", url: "https://www.psychologytoday.com", type: "MEDIA", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "2330\u4E07/\u6708", suitableFor: "\u5927\u4F17/\u4ECE\u4E1A\u8005", featured: true, description: "\u5168\u7403\u6700\u5927\u5FC3\u7406\u5B66\u95E8\u6237\uFF1A\u79D1\u666E\u5185\u5BB9 + \u5168\u7403\u6700\u5927\u54A8\u8BE2\u5E08\u76EE\u5F55\uFF08Find a Therapist\uFF09\u3002", tags: ["\u79D1\u666E", "\u54A8\u8BE2\u5E08\u76EE\u5F55", "\u53CC\u8FB9\u6A21\u5F0F"] },
  { name: "16Personalities", url: "https://www.16personalities.com", type: "TOOL", country: "\u7F8E\u56FD", language: "\u591A\u8BED\u8A00", trafficLevel: "1888\u4E07/\u6708", suitableFor: "\u5927\u4F17/\u5B66\u751F", featured: true, description: "\u514D\u8D39 MBTI \u98CE\u683C\u4EBA\u683C\u6D4B\u8BD5\uFF0C\u5168\u7403\u6D41\u91CF\u6700\u9AD8\u7684\u5FC3\u7406\u6D4B\u8BC4\u7AD9\u4E4B\u4E00\u3002", tags: ["\u4EBA\u683C\u6D4B\u8BD5", "\u6D4B\u8BC4", "\u514D\u8D39"] },
  { name: "SimplePractice", url: "https://www.simplepractice.com", type: "SAAS", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "970\u4E07/\u6708", suitableFor: "\u4ECE\u4E1A\u8005", featured: true, description: "\u5317\u7F8E\u6700\u5927\u5FC3\u7406\u54A8\u8BE2\u6267\u4E1A\u7BA1\u7406 SaaS\uFF08\u9884\u7EA6\u3001\u75C5\u5386\u3001\u8BA1\u8D39\u3001\u8FDC\u7A0B\u4F1A\u8C08\uFF09\u3002", tags: ["\u6267\u4E1ASaaS", "EHR", "\u5DE5\u4F5C\u53F0"] },
  { name: "APA (\u7F8E\u56FD\u5FC3\u7406\u5B66\u4F1A)", url: "https://www.apa.org", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "837\u4E07/\u6708", suitableFor: "\u7814\u7A76\u8005/\u4ECE\u4E1A\u8005", featured: true, description: "APA \u683C\u5F0F\u89C4\u8303\u3001\u671F\u520A\u6570\u636E\u5E93 PsycINFO\u3001\u6267\u4E1A\u4F26\u7406\u6807\u51C6\u6E90\u5934\u3002", tags: ["\u534F\u4F1A", "\u6743\u5A01", "\u671F\u520A"] },
  { name: "BetterHelp", url: "https://www.betterhelp.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "700\u4E07/\u6708", suitableFor: "\u5927\u4F17", featured: true, description: "\u5168\u7403\u6700\u5927 DTC \u5728\u7EBF\u5FC3\u7406\u54A8\u8BE2\u5E73\u53F0\uFF08\u8BA2\u9605\u5236\uFF09\u3002", tags: ["\u5728\u7EBF\u54A8\u8BE2", "\u8BA2\u9605", "\u5BFC\u6D41"] },
  { name: "Verywell Mind", url: "https://www.verywellmind.com", type: "MEDIA", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "650\u4E07/\u6708", suitableFor: "\u5927\u4F17", featured: true, description: "Dotdash Meredith \u65D7\u4E0B\u5FC3\u7406\u79D1\u666E\u5A92\u4F53\uFF0CSEO \u957F\u6587 + \u533B\u5B66\u5BA1\u6838\u4F53\u7CFB\u3002", tags: ["\u79D1\u666E", "SEO", "\u533B\u5B66\u5BA1\u6838"] },
  { name: "Headway", url: "https://www.headway.co", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "530\u4E07/\u6708", suitableFor: "\u5927\u4F17/\u4ECE\u4E1A\u8005", description: "\u4FDD\u9669\u5185\u5FC3\u7406\u6CBB\u7597\u64AE\u5408\u72EC\u89D2\u517D\uFF1A\u5E2E\u54A8\u8BE2\u5E08\u63A5\u5165\u533B\u4FDD\u7F51\u7EDC\u3002", tags: ["\u4FDD\u9669\u64AE\u5408", "\u54A8\u8BE2\u5E08\u5339\u914D"] },
  { name: "Simply Psychology", url: "https://www.simplypsychology.org", type: "EDU", country: "\u82F1\u56FD", language: "\u82F1\u8BED", trafficLevel: "180-300\u4E07/\u6708", suitableFor: "\u5B66\u751F/\u7814\u7A76\u8005", description: "\u9762\u5411\u5B66\u751F\u7684\u7406\u8BBA\u8BCD\u6761\uFF0C\u5B66\u672F\u5F15\u7528\u8D85 2.6 \u4E07\u6B21\uFF0C\u5FC3\u7406\u5B66\u5B66\u751F\u7B2C\u4E00\u7AD9\u3002", tags: ["\u8BCD\u6761", "\u6559\u80B2", "\u7406\u8BBA"] },
  { name: "Psych Central", url: "https://psychcentral.com", type: "MEDIA", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "140\u4E07/\u6708", suitableFor: "\u5927\u4F17", description: "\u8001\u724C\u5FC3\u7406\u79D1\u666E\u7AD9\uFF0C\u79D1\u666E + \u514D\u8D39\u81EA\u6D4B\u53CC\u8F6E\u9A71\u52A8\u3002", tags: ["\u79D1\u666E", "\u81EA\u6D4B"] },
  { name: "Mind (\u82F1\u56FD\u5FC3\u7406\u5065\u5EB7\u7684\u6148\u5584)", url: "https://www.mind.org.uk", type: "ORG", country: "\u82F1\u56FD", language: "\u82F1\u8BED", trafficLevel: "130\u4E07/\u6708", suitableFor: "\u5927\u4F17", description: "\u82F1\u56FD\u6700\u5927\u5FC3\u7406\u5065\u5EB7\u516C\u76CA\u7EC4\u7EC7\uFF0C\u6743\u5A01\u79D1\u666E + \u6C42\u52A9\u6307\u5357 + \u653F\u7B56\u5021\u5BFC\u3002", tags: ["\u516C\u76CA", "\u6C42\u52A9\u6307\u5357", "\u6743\u5A01"] },
  { name: "Calm", url: "https://www.calm.com", type: "MEDITATION", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u5927\u4F17", description: "\u5168\u7403\u6700\u5927\u51A5\u60F3 / \u7761\u7720\u5E94\u7528\u4E4B\u4E00\uFF0C\u7F51\u7AD9\u4E3A App \u8BA2\u9605\u5BFC\u6D41\u3002", tags: ["\u51A5\u60F3", "\u7761\u7720", "App"] },
  { name: "Headspace", url: "https://www.headspace.com", type: "MEDITATION", country: "\u7F8E\u56FD/\u82F1\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u5927\u4F17", description: "\u4E0E Calm \u53CC\u96C4\u5E76\u7ACB\u7684\u6B63\u5FF5\u5E94\u7528\uFF0C\u5DF2\u62D3\u5C55\u4F01\u4E1A EAP \u670D\u52A1\u3002", tags: ["\u6B63\u5FF5", "\u51A5\u60F3", "EAP"] },
  { name: "7 Cups", url: "https://www.7cups.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u591A\u8BED\u8A00", trafficLevel: "\u9AD8", suitableFor: "\u5927\u4F17", description: "\u514D\u8D39\u60C5\u611F\u652F\u6301\u793E\u533A\uFF1A\u5FD7\u613F\u503E\u542C\u8005 + \u4F4E\u4EF7\u54A8\u8BE2\uFF0C189 \u56FD\u591A\u8BED\u8A00\u3002", tags: ["\u4E92\u52A9\u793E\u533A", "\u503E\u542C\u8005", "UGC"] },
  { name: "TherapyNotes", url: "https://www.therapynotes.com", type: "SAAS", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u5FC3\u7406\u5065\u5EB7\u4E13\u7528\u7535\u5B50\u75C5\u5386\uFF08EHR\uFF09\uFF0C\u5168\u699C\u7C98\u6027\u4E4B\u738B\u3002", tags: ["EHR", "\u6267\u4E1ASaaS", "\u9AD8\u7C98\u6027"] },
  { name: "Grow Therapy", url: "https://www.growtherapy.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u5927\u4F17/\u4ECE\u4E1A\u8005", description: "Headway \u540C\u8D5B\u9053\uFF1A\u54A8\u8BE2\u5E08\u5339\u914D + \u4FDD\u9669\u7ED3\u7B97 + \u6267\u4E1A\u652F\u6301\u4E09\u5408\u4E00\u3002", tags: ["\u4FDD\u9669\u64AE\u5408", "\u5339\u914D"] },
  { name: "Talkspace", url: "https://www.talkspace.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u5927\u4F17", description: "\u4E0A\u5E02\u5728\u7EBF\u6CBB\u7597\u5E73\u53F0\uFF08NASDAQ:TALK\uFF09\uFF0C\u6587\u5B57 + \u89C6\u9891\u6CBB\u7597\u3002", tags: ["\u5728\u7EBF\u54A8\u8BE2", "\u4E0A\u5E02"] },
  { name: "NOCD (TreatMyOCD)", url: "https://www.treatmyocd.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u60A3\u8005/\u5927\u4F17", description: "\u5F3A\u8FEB\u75C7 ERP \u7597\u6CD5\u4E13\u79D1\u5E73\u53F0\uFF0C\u300C\u5355\u75C5\u79CD\u6DF1\u8015\u300D\u6210\u529F\u6837\u672C\u3002", tags: ["\u5355\u75C5\u79CD", "\u5F3A\u8FEB\u75C7", "ERP"] },
  { name: "ADDitude", url: "https://www.additudemag.com", type: "MEDIA", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "140\u4E07/\u6708", suitableFor: "\u60A3\u8005/\u5BB6\u5EAD", description: "ADHD \u5782\u76F4\u5A92\u4F53\uFF0C\u4E13\u75C5\u5185\u5BB9 + \u7F51\u8BFE + \u8BB2\u5EA7\u53D8\u73B0\u3002", tags: ["ADHD", "\u5782\u76F4", "\u5355\u75C5\u79CD"] },
  { name: "MHA (Mental Health America)", url: "https://www.mhanational.org", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5927\u4F17/\u7B5B\u67E5", description: "\u514D\u8D39\u5728\u7EBF\u5FC3\u7406\u7B5B\u67E5\u5DE5\u5177\u6700\u5927\u63D0\u4F9B\u65B9\uFF08\u5E74\u5343\u4E07\u6B21\u6D4B\u8BD5\uFF09\u3002", tags: ["\u516C\u76CA", "\u7B5B\u67E5", "\u514D\u8D39\u6D4B\u8BC4"] },
  { name: "NIMH", url: "https://www.nimh.nih.gov", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u9AD8", suitableFor: "\u7814\u7A76\u8005/\u5927\u4F17", description: "\u7F8E\u56FD\u56FD\u7ACB\u7CBE\u795E\u536B\u751F\u7814\u7A76\u6240\uFF0C\u7814\u7A76\u7ECF\u8D39\u4E0E\u6D41\u884C\u75C5\u5B66\u7EDF\u8BA1\u6743\u5A01\u6E90\u3002", tags: ["\u653F\u5E9C", "\u7814\u7A76", "\u6743\u5A01"] },
  { name: "SAMHSA", url: "https://www.samhsa.gov", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005/\u5927\u4F17", description: "\u7F8E\u56FD\u836F\u7269\u6EE5\u7528\u4E0E\u5FC3\u7406\u5065\u5EB7\u670D\u52A1\u7BA1\u7406\u5C40\uFF0C\u6CBB\u7597\u673A\u6784\u67E5\u8BE2\u5668\u3002", tags: ["\u653F\u5E9C", "\u673A\u6784\u67E5\u8BE2"] },
  { name: "988 Suicide & Crisis Lifeline", url: "https://988lifeline.org", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5371\u673A\u4EBA\u7FA4", description: "\u7F8E\u56FD\u5168\u56FD\u81EA\u6740\u4E0E\u5371\u673A\u5E72\u9884\u70ED\u7EBF\u5B98\u7F51\uFF0C\u516C\u5171\u536B\u751F\u57FA\u7840\u8BBE\u65BD\u3002", tags: ["\u5371\u673A\u70ED\u7EBF", "\u81EA\u6740\u5E72\u9884"] },
  { name: "Find a Helpline", url: "https://findahelpline.com", type: "ORG", country: "\u65B0\u897F\u5170", language: "\u591A\u8BED\u8A00", trafficLevel: "\u4E2D", suitableFor: "\u5371\u673A\u4EBA\u7FA4", description: "\u5168\u7403\u5371\u673A\u70ED\u7EBF\u805A\u5408\u5668\uFF08130+ \u56FD\u5BB6\uFF09\uFF0C\u5DF2\u88AB Google \u5F15\u7528\u3002", tags: ["\u6C42\u52A9\u805A\u5408", "\u70ED\u7EBF", "\u5168\u7403"] },
  { name: "Psychiatry.org", url: "https://www.psychiatry.org", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u7F8E\u56FD\u7CBE\u795E\u533B\u5B66\u5B66\u4F1A\uFF0CDSM-5-TR \u8BCA\u65AD\u6807\u51C6\u51FA\u7248\u65B9\u3002", tags: ["\u534F\u4F1A", "DSM", "\u8BCA\u65AD\u6807\u51C6"] },
  { name: "Psychiatry Online", url: "https://psychiatryonline.org", type: "EDU", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005/\u7814\u7A76\u8005", description: "APA Publishing \u5B66\u672F\u5E73\u53F0\uFF1ADSM \u56FE\u4E66\u9986 + \u9876\u520A\uFF0C\u673A\u6784\u8BA2\u9605\u5236\u3002", tags: ["\u5B66\u672F", "\u51FA\u7248", "\u671F\u520A"] },
  { name: "Therapist Aid", url: "https://www.therapistaid.com", type: "TOOL", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u54A8\u8BE2\u5E08\u6CBB\u7597\u5DE5\u4F5C\u8868 / \u5FC3\u7406\u6559\u80B2\u7D20\u6750\u5E93\uFF08\u514D\u8D39 + \u8BA2\u9605\uFF09\u3002", tags: ["\u7D20\u6750\u5E93", "\u5DE5\u4F5C\u8868", "\u4ECE\u4E1A\u8005"] },
  { name: "NovoPsych", url: "https://novopsych.com", type: "TOOL", country: "\u6FB3\u5927\u5229\u4E9A", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u9762\u5411\u6267\u4E1A\u8005\u7684\u6807\u51C6\u5316\u5FC3\u7406\u91CF\u8868\u65BD\u6D4B / \u8BA1\u5206 SaaS\u3002", tags: ["\u91CF\u8868", "\u8BA1\u5206", "\u4ECE\u4E1A\u8005"] },
  { name: "Embrace Autism", url: "https://embrace-autism.com", type: "TOOL", country: "\u52A0\u62FF\u5927", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5927\u4F17/\u7B5B\u67E5", description: "\u6210\u4EBA\u81EA\u95ED\u75C7\u81EA\u8BC4\u6D4B\u9A8C\u5E93 + \u79D1\u666E\uFF0C\u300C\u4E13\u4E1A\u91CF\u8868\u5728\u7EBF\u5316\u300D\u5178\u578B\u3002", tags: ["\u81EA\u95ED\u75C7", "\u81EA\u6D4B", "\u6D4B\u8BC4"] },
  { name: "Attachment Project", url: "https://attachmentproject.com", type: "MEDIA", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5927\u4F17", description: "\u4F9D\u604B\u7406\u8BBA\u4E3B\u9898\u7AD9\uFF1A\u514D\u8D39\u4F9D\u604B\u7C7B\u578B\u6D4B\u8BD5\u5F15\u6D41 \u2192 \u4ED8\u8D39\u8BFE\u7A0B\u8F6C\u5316\u3002", tags: ["\u4F9D\u604B", "\u4E3B\u9898", "\u6D4B\u8BD5"] },
  { name: "HelpGuide", url: "https://www.helpguide.org", type: "ORG", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5927\u4F17", description: "\u975E\u8425\u5229\u5FC3\u7406\u81EA\u52A9\u6307\u5357\uFF08\u4E0E\u54C8\u4F5B\u5065\u5EB7\u5408\u4F5C\uFF09\uFF0C\u65E0\u5E7F\u544A\u3002", tags: ["\u516C\u76CA", "\u81EA\u52A9", "\u6307\u5357"] },
  { name: "Gottman Institute", url: "https://www.gottman.com", type: "EDU", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005/\u592B\u59BB", description: "\u5A5A\u59FB\u5BB6\u5EAD\u6CBB\u7597\u7814\u7A76\u673A\u6784\uFF0C\u8BFE\u7A0B\u8BA4\u8BC1 + \u5DE5\u4F5C\u574A + \u56FE\u4E66\u3002", tags: ["\u6D41\u6D3EIP", "\u5A5A\u59FB", "\u8BA4\u8BC1"] },
  { name: "Spring Health", url: "https://www.springhealth.com", type: "THERAPY", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4F01\u4E1A", description: "AI \u7CBE\u51C6\u5339\u914D\u7684\u4F01\u4E1A\u5458\u5DE5\u5FC3\u7406\u5065\u5EB7\u5E73\u53F0\uFF08EAP 2.0\uFF09\u3002", tags: ["\u4F01\u4E1AEAP", "AI\u5339\u914D"] },
  { name: "Psychologies (RU)", url: "https://www.psychologies.ru", type: "MEDIA", country: "\u4FC4\u7F57\u65AF", language: "\u4FC4\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u5927\u4F17", description: "\u4FC4\u8BED\u7248\u300APsychologies\u300B\u6742\u5FD7\uFF0C\u4FC4\u8BED\u533A\u6700\u5927\u5FC3\u7406\u5A92\u4F53\u3002", tags: ["\u5A92\u4F53", "\u4FC4\u8BED"] },
  { name: "Doxy.me", url: "https://doxy.me", type: "SAAS", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u514D\u8D39 HIPAA \u5408\u89C4\u8FDC\u7A0B\u89C6\u9891\u95EE\u8BCA\u5DE5\u5177\uFF0C\u88AB\u5927\u91CF\u54A8\u8BE2\u5E08\u4F7F\u7528\u3002", tags: ["\u8FDC\u7A0B\u95EE\u8BCA", "\u89C6\u9891", "HIPAA"] },
  { name: "Halaxy", url: "https://www.halaxy.com", type: "SAAS", country: "\u6FB3\u5927\u5229\u4E9A", language: "\u82F1\u8BED", trafficLevel: "\u4E2D", suitableFor: "\u4ECE\u4E1A\u8005", description: "\u514D\u8D39\u5065\u5EB7\u6267\u4E1A\u7BA1\u7406\u5E73\u53F0\uFF0C\u9760\u652F\u4ED8\u4E0E\u589E\u503C\u670D\u52A1\u53D8\u73B0\u3002", tags: ["\u6267\u4E1ASaaS", "\u514D\u8D39"] }
];
var helplines = [
  { name: "\u4E2D\u56FD\u5FC3\u7406\u5371\u673A\u5E72\u9884\u70ED\u7EBF", country: "\u4E2D\u56FD", language: "\u4E2D\u6587", phone: "400-161-9995", url: "https://www.crisis.org.cn", description: "\u5E0C\u671B24\u70ED\u7EBF\uFF0C\u5168\u56FD\u5FC3\u7406\u5371\u673A\u5E72\u9884\u4E0E\u81EA\u6740\u9884\u9632\u3002", category: "CRISIS" },
  { name: "\u5317\u4EAC\u5FC3\u7406\u63F4\u52A9\u70ED\u7EBF", country: "\u4E2D\u56FD", language: "\u4E2D\u6587", phone: "010-82951332", url: "", description: "\u5317\u4EAC\u56DE\u9F99\u89C2\u533B\u9662\u5FC3\u7406\u5371\u673A\u5E72\u9884\u70ED\u7EBF\u3002", category: "CRISIS" },
  { name: "\u7F8E\u56FD 988 \u81EA\u6740\u4E0E\u5371\u673A\u751F\u547D\u7EBF", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", phone: "988", url: "https://988lifeline.org", description: "\u5168\u7F8E\u7EDF\u4E00\u81EA\u6740\u4E0E\u5371\u673A\u5E72\u9884\u70ED\u7EBF\uFF08\u591A\u8BED\u8A00\uFF09\u3002", category: "CRISIS" },
  { name: "\u82F1\u56FD Samaritans", country: "\u82F1\u56FD", language: "\u82F1\u8BED", phone: "116 123", url: "https://www.samaritans.org", description: "24 \u5C0F\u65F6\u60C5\u7EEA\u652F\u6301\u4E0E\u5371\u673A\u503E\u542C\u70ED\u7EBF\u3002", category: "CRISIS" },
  { name: "\u6FB3\u5927\u5229\u4E9A Lifeline", country: "\u6FB3\u5927\u5229\u4E9A", language: "\u82F1\u8BED", phone: "13 11 14", url: "https://www.lifeline.org.au", description: "24 \u5C0F\u65F6\u5371\u673A\u652F\u6301\u4E0E\u81EA\u6740\u9884\u9632\u70ED\u7EBF\u3002", category: "CRISIS" },
  { name: "Find a Helpline\uFF08\u5168\u7403\uFF09", country: "\u5168\u7403", language: "\u591A\u8BED\u8A00", phone: "", url: "https://findahelpline.com", description: "\u6309\u56FD\u5BB6 / \u8BED\u8A00\u68C0\u7D22\u7684\u5168\u7403\u5371\u673A\u70ED\u7EBF\u805A\u5408\u5668\uFF08130+ \u56FD\u5BB6\uFF09\u3002", category: "SUPPORT" },
  { name: "MHA \u514D\u8D39\u5728\u7EBF\u7B5B\u67E5", country: "\u7F8E\u56FD", language: "\u82F1\u8BED", phone: "", url: "https://screening.mhanational.org", description: "\u5FC3\u7406\u5065\u5EB7\u7F8E\u56FD\u534F\u4F1A\u63D0\u4F9B\u7684\u514D\u8D39\u81EA\u8BC4\u7B5B\u67E5\u5DE5\u5177\u3002", category: "LOW_COST" }
];
var OPTS = [
  { score: 0, label: "\u5B8C\u5168\u4E0D\u4F1A" },
  { score: 1, label: "\u597D\u51E0\u5929" },
  { score: 2, label: "\u4E00\u534A\u4EE5\u4E0A\u7684\u5929\u6570" },
  { score: 3, label: "\u51E0\u4E4E\u6BCF\u5929" }
];
var assessments = [
  {
    slug: "phq-9",
    title: "PHQ-9 \u6291\u90C1\u7B5B\u67E5\u91CF\u8868",
    description: "\u60A3\u8005\u5065\u5EB7\u95EE\u5377\u6291\u90C1\u91CF\u8868\uFF089 \u9879\uFF09\uFF0C\u7528\u4E8E\u6291\u90C1\u75C7\u72B6\u81EA\u8BC4\u4E0E\u4E25\u91CD\u7A0B\u5EA6\u5206\u7EA7\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\uFF0C\u4E0D\u6784\u6210\u8BCA\u65AD\u3002",
    type: "DEPRESSION",
    questions: [
      "\u505A\u4E8B\u65F6\u63D0\u4E0D\u8D77\u52B2\u6216\u6CA1\u6709\u5174\u8DA3",
      "\u611F\u5230\u5FC3\u60C5\u4F4E\u843D\u3001\u6CAE\u4E27\u6216\u7EDD\u671B",
      "\u5165\u7761\u56F0\u96BE\u3001\u7761\u4E0D\u5B89\u7A33\u6216\u7761\u7720\u8FC7\u591A",
      "\u611F\u89C9\u75B2\u5026\u6216\u6CA1\u6709\u6D3B\u529B",
      "\u98DF\u6B32\u4E0D\u632F\u6216\u5403\u592A\u591A",
      "\u89C9\u5F97\u81EA\u5DF1\u5F88\u7CDF\uFF0C\u6216\u89C9\u5F97\u81EA\u5DF1\u5F88\u5931\u8D25\uFF0C\u6216\u8BA9\u81EA\u5DF1\u6216\u5BB6\u4EBA\u5931\u671B",
      "\u5BF9\u4E8B\u7269\u4E13\u6CE8\u6709\u56F0\u96BE\uFF0C\u4F8B\u5982\u9605\u8BFB\u62A5\u7EB8\u6216\u770B\u7535\u89C6\u65F6",
      "\u884C\u52A8\u6216\u8BF4\u8BDD\u901F\u5EA6\u7F13\u6162\u5230\u522B\u4EBA\u5DF2\u7ECF\u5BDF\u89C9\uFF1F\u6216\u6B63\u597D\u76F8\u53CD\u2014\u2014\u53D8\u5F97\u6BD4\u5E73\u5E38\u66F4\u70E6\u8E81\u6216\u5750\u7ACB\u4E0D\u5B89",
      "\u6709\u4E0D\u5982\u6B7B\u6389\u6216\u7528\u67D0\u79CD\u65B9\u5F0F\u4F24\u5BB3\u81EA\u5DF1\u7684\u5FF5\u5934"
    ].map((text, i) => ({ id: `q${i + 1}`, text, options: OPTS })),
    interpretation: {
      bands: [
        { max: 4, level: "\u65E0\u6216\u6781\u8F7B\u5FAE", advice: "\u75C7\u72B6\u6781\u8F7B\u5FAE\uFF0C\u4FDD\u6301\u5173\u6CE8\u5373\u53EF\u3002" },
        { max: 9, level: "\u8F7B\u5EA6", advice: "\u5EFA\u8BAE\u81EA\u6211\u8C03\u8282\u5E76\u89C2\u5BDF\uFF0C\u5982\u6301\u7EED\u4E24\u5468\u4EE5\u4E0A\u8BF7\u5BFB\u6C42\u5E2E\u52A9\u3002" },
        { max: 14, level: "\u4E2D\u5EA6", advice: "\u5EFA\u8BAE\u54A8\u8BE2\u4E13\u4E1A\u5FC3\u7406\u4EBA\u5458\u3002" },
        { max: 19, level: "\u4E2D\u91CD\u5EA6", advice: "\u5EFA\u8BAE\u5C3D\u5FEB\u5BFB\u6C42\u4E13\u4E1A\u8BC4\u4F30\u4E0E\u5E2E\u52A9\u3002" },
        { max: 27, level: "\u91CD\u5EA6", advice: "\u5EFA\u8BAE\u5C3D\u5FEB\u5C31\u533B\uFF0C\u5FC5\u8981\u65F6\u8054\u7CFB\u5371\u673A\u5E72\u9884\u70ED\u7EBF\u3002" }
      ]
    },
    source: "PHQ-9\uFF08\u516C\u5171\u9886\u57DF\uFF0CPfizer \u6388\u6743\u514D\u8D39\u4F7F\u7528\uFF09"
  },
  {
    slug: "gad-7",
    title: "GAD-7 \u7126\u8651\u7B5B\u67E5\u91CF\u8868",
    description: "\u5E7F\u6CDB\u6027\u7126\u8651\u969C\u788D\u91CF\u8868\uFF087 \u9879\uFF09\uFF0C\u7528\u4E8E\u7126\u8651\u75C7\u72B6\u81EA\u8BC4\u4E0E\u4E25\u91CD\u7A0B\u5EA6\u5206\u7EA7\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\uFF0C\u4E0D\u6784\u6210\u8BCA\u65AD\u3002",
    type: "ANXIETY",
    questions: [
      "\u611F\u5230\u7D27\u5F20\u3001\u7126\u8651\u6216\u6025\u5207",
      "\u4E0D\u80FD\u591F\u505C\u6B62\u6216\u63A7\u5236\u62C5\u5FE7",
      "\u5BF9\u5404\u79CD\u5404\u6837\u7684\u4E8B\u60C5\u62C5\u5FE7\u8FC7\u591A",
      "\u5F88\u96BE\u653E\u677E\u4E0B\u6765",
      "\u7531\u4E8E\u4E0D\u5B89\u800C\u65E0\u6CD5\u9759\u5750",
      "\u53D8\u5F97\u5BB9\u6613\u70E6\u607C\u6216\u6025\u8E81",
      "\u611F\u5230\u4F3C\u4E4E\u5C06\u6709\u53EF\u6015\u7684\u4E8B\u60C5\u53D1\u751F\u800C\u5BB3\u6015"
    ].map((text, i) => ({ id: `q${i + 1}`, text, options: OPTS })),
    interpretation: {
      bands: [
        { max: 4, level: "\u65E0\u6216\u6781\u8F7B\u5FAE", advice: "\u75C7\u72B6\u6781\u8F7B\u5FAE\uFF0C\u4FDD\u6301\u5173\u6CE8\u5373\u53EF\u3002" },
        { max: 9, level: "\u8F7B\u5EA6", advice: "\u5EFA\u8BAE\u81EA\u6211\u8C03\u8282\u5E76\u89C2\u5BDF\u3002" },
        { max: 14, level: "\u4E2D\u5EA6", advice: "\u5EFA\u8BAE\u54A8\u8BE2\u4E13\u4E1A\u5FC3\u7406\u4EBA\u5458\u3002" },
        { max: 21, level: "\u91CD\u5EA6", advice: "\u5EFA\u8BAE\u5C3D\u5FEB\u5BFB\u6C42\u4E13\u4E1A\u8BC4\u4F30\u4E0E\u5E2E\u52A9\u3002" }
      ]
    },
    source: "GAD-7\uFF08\u516C\u5171\u9886\u57DF\uFF0CPfizer \u6388\u6743\u514D\u8D39\u4F7F\u7528\uFF09"
  },
  {
    slug: "sds",
    title: "SDS \u6291\u90C1\u81EA\u8BC4\u91CF\u8868\uFF08Zung\uFF09",
    description: "Zung \u6291\u90C1\u81EA\u8BC4\u91CF\u8868\uFF0820 \u9879\uFF09\uFF0C\u7ECF\u5178\u516C\u7248\u6291\u90C1\u7B5B\u67E5\u5DE5\u5177\uFF0C\u8986\u76D6\u60C5\u7EEA\u3001\u8EAF\u4F53\u4E0E\u5FC3\u7406\u5C42\u9762\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\u3002",
    type: "DEPRESSION",
    questions: [
      "\u6211\u611F\u5230\u60C5\u7EEA\u6CAE\u4E27\u3001\u90C1\u95F7",
      "\u6211\u611F\u5230\u65E9\u6668\u5FC3\u60C5\u6700\u597D",
      "\u6211\u8981\u54ED\u6216\u60F3\u54ED",
      "\u6211\u591C\u95F4\u7761\u7720\u4E0D\u597D",
      "\u6211\u5403\u996D\u50CF\u5E73\u65F6\u4E00\u6837\u591A",
      "\u6211\u7684\u6027\u529F\u80FD\u6B63\u5E38",
      "\u6211\u611F\u5230\u4F53\u91CD\u4E0B\u964D",
      "\u6211\u4E3A\u4FBF\u79D8\u70E6\u607C",
      "\u6211\u7684\u5FC3\u8DF3\u6BD4\u5E73\u65F6\u5FEB",
      "\u6211\u65E0\u6545\u611F\u5230\u75B2\u52B3",
      "\u6211\u7684\u5934\u8111\u50CF\u5F80\u5E38\u4E00\u6837\u6E05\u695A",
      "\u6211\u505A\u4E8B\u60C5\u50CF\u5E73\u65F6\u4E00\u6837\u4E0D\u611F\u5230\u56F0\u96BE",
      "\u6211\u5750\u5367\u4E0D\u5B89\u3001\u96BE\u4EE5\u4FDD\u6301\u5E73\u9759",
      "\u6211\u5BF9\u672A\u6765\u611F\u5230\u6709\u5E0C\u671B",
      "\u6211\u6BD4\u5E73\u65F6\u66F4\u5BB9\u6613\u6FC0\u60F9",
      "\u6211\u89C9\u5F97\u51B3\u5B9A\u4EC0\u4E48\u4E8B\u5F88\u5BB9\u6613",
      "\u6211\u611F\u5230\u81EA\u5DF1\u662F\u6709\u7528\u7684\u548C\u4E0D\u53EF\u7F3A\u5C11\u7684\u4EBA",
      "\u6211\u7684\u751F\u6D3B\u8FC7\u5F97\u5F88\u6709\u610F\u601D",
      "\u6211\u8BA4\u4E3A\u5982\u679C\u6211\u6B7B\u4E86\u522B\u4EBA\u4F1A\u8FC7\u5F97\u66F4\u597D",
      "\u6211\u5BF9\u5E73\u65F6\u611F\u5174\u8DA3\u7684\u4E8B\u4ECD\u7136\u611F\u5174\u8DA3"
    ].map((text, i) => ({
      id: `q${i + 1}`,
      text,
      options: OPTS,
      // Zung 反向计分题（正向表述 → 反向计）
      reverse: [1, 4, 10, 12, 13, 16, 17, 19].includes(i)
    })),
    interpretation: {
      bands: [
        { max: 20, level: "\u65E0\u6216\u6781\u8F7B\u5FAE", advice: "\u6291\u90C1\u503E\u5411\u4E0D\u660E\u663E\uFF0C\u4FDD\u6301\u5173\u6CE8\u5373\u53EF\u3002" },
        { max: 40, level: "\u8F7B\u5EA6", advice: "\u5B58\u5728\u8F7B\u5EA6\u6291\u90C1\u503E\u5411\uFF0C\u5EFA\u8BAE\u81EA\u6211\u8C03\u8282\u5E76\u89C2\u5BDF\u3002" },
        { max: 60, level: "\u4E2D\u5EA6", advice: "\u4E2D\u5EA6\u6291\u90C1\u503E\u5411\uFF0C\u5EFA\u8BAE\u54A8\u8BE2\u4E13\u4E1A\u5FC3\u7406\u4EBA\u5458\u3002" },
        { max: 80, level: "\u91CD\u5EA6", advice: "\u91CD\u5EA6\u6291\u90C1\u503E\u5411\uFF0C\u5EFA\u8BAE\u5C3D\u5FEB\u5BFB\u6C42\u4E13\u4E1A\u8BC4\u4F30\u4E0E\u5E2E\u52A9\u3002" }
      ]
    },
    source: "SDS\uFF08Zung 1965\uFF0C\u516C\u7248\u81EA\u8BC4\u91CF\u8868\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF0C\u4EC5\u4F9B\u793A\u610F\uFF09"
  },
  {
    slug: "sas",
    title: "SAS \u7126\u8651\u81EA\u8BC4\u91CF\u8868\uFF08Zung\uFF09",
    description: "Zung \u7126\u8651\u81EA\u8BC4\u91CF\u8868\uFF0820 \u9879\uFF09\uFF0C\u7ECF\u5178\u516C\u7248\u7126\u8651\u7B5B\u67E5\u5DE5\u5177\uFF0C\u542B\u8EAF\u4F53\u4E0E\u4E3B\u89C2\u7126\u8651\u7EF4\u5EA6\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\u3002",
    type: "ANXIETY",
    questions: [
      "\u6211\u611F\u5230\u6BD4\u5F80\u5E38\u66F4\u52A0\u795E\u7ECF\u8FC7\u654F\u548C\u7126\u8651",
      "\u6211\u65E0\u7F18\u65E0\u6545\u611F\u5230\u62C5\u5FC3",
      "\u6211\u5BB9\u6613\u5FC3\u70E6\u610F\u4E71\u6216\u611F\u5230\u6050\u614C",
      "\u6211\u89C9\u5F97\u6211\u53EF\u80FD\u5C06\u8981\u53D1\u75AF",
      "\u6211\u611F\u5230\u4E8B\u4E8B\u90FD\u5F88\u987A\u5229\uFF0C\u4E0D\u4F1A\u6709\u5012\u9709\u7684\u4E8B\u53D1\u751F",
      "\u6211\u7684\u56DB\u80A2\u6296\u52A8\u548C\u9707\u98A4",
      "\u6211\u56E0\u5934\u75DB\u3001\u9888\u75DB\u548C\u80CC\u75DB\u800C\u70E6\u607C",
      "\u6211\u611F\u5230\u65E0\u529B\u4E14\u5BB9\u6613\u75B2\u52B3",
      "\u6211\u611F\u5230\u5E73\u9759\uFF0C\u80FD\u5B89\u9759\u5750\u4E0B",
      "\u6211\u611F\u5230\u6211\u7684\u5FC3\u8DF3\u8F83\u5FEB",
      "\u6211\u56E0\u9635\u9635\u7684\u5934\u6655\u800C\u70E6\u607C",
      "\u6211\u6709\u9635\u9635\u6655\u5012\u7684\u611F\u89C9\u6216\u89C9\u5F97\u8981\u6655\u5012\u4F3C\u7684",
      "\u6211\u547C\u6C14\u5438\u6C14\u90FD\u611F\u5230\u5F88\u5BB9\u6613",
      "\u6211\u7684\u624B\u6307\u548C\u811A\u8DBE\u611F\u5230\u9EBB\u6728\u548C\u523A\u75DB",
      "\u6211\u56E0\u80C3\u75DB\u548C\u6D88\u5316\u4E0D\u826F\u800C\u82E6\u607C",
      "\u6211\u5FC5\u987B\u9891\u7E41\u6392\u5C3F",
      "\u6211\u7684\u624B\u603B\u662F\u6E29\u6696\u800C\u5E72\u71E5",
      "\u6211\u89C9\u5F97\u8138\u53D1\u70E7\u53D1\u7EA2",
      "\u6211\u5BB9\u6613\u5165\u7761\u5E76\u4E14\u4E00\u591C\u7761\u5F97\u5F88\u597D",
      "\u6211\u505A\u6076\u68A6"
    ].map((text, i) => ({
      id: `q${i + 1}`,
      text,
      options: OPTS,
      reverse: [4, 8, 12, 16, 18].includes(i)
    })),
    interpretation: {
      bands: [
        { max: 20, level: "\u65E0\u6216\u6781\u8F7B\u5FAE", advice: "\u7126\u8651\u503E\u5411\u4E0D\u660E\u663E\uFF0C\u4FDD\u6301\u5173\u6CE8\u5373\u53EF\u3002" },
        { max: 40, level: "\u8F7B\u5EA6", advice: "\u5B58\u5728\u8F7B\u5EA6\u7126\u8651\u503E\u5411\uFF0C\u5EFA\u8BAE\u81EA\u6211\u8C03\u8282\u5E76\u89C2\u5BDF\u3002" },
        { max: 60, level: "\u4E2D\u5EA6", advice: "\u4E2D\u5EA6\u7126\u8651\u503E\u5411\uFF0C\u5EFA\u8BAE\u54A8\u8BE2\u4E13\u4E1A\u5FC3\u7406\u4EBA\u5458\u3002" },
        { max: 80, level: "\u91CD\u5EA6", advice: "\u91CD\u5EA6\u7126\u8651\u503E\u5411\uFF0C\u5EFA\u8BAE\u5C3D\u5FEB\u5BFB\u6C42\u4E13\u4E1A\u8BC4\u4F30\u4E0E\u5E2E\u52A9\u3002" }
      ]
    },
    source: "SAS\uFF08Zung 1971\uFF0C\u516C\u7248\u81EA\u8BC4\u91CF\u8868\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF0C\u4EC5\u4F9B\u793A\u610F\uFF09"
  },
  {
    slug: "pss-10",
    title: "PSS-10 \u611F\u77E5\u538B\u529B\u91CF\u8868",
    description: "\u611F\u77E5\u538B\u529B\u91CF\u8868\uFF0810 \u9879\uFF09\uFF0C\u8BC4\u4F30\u8FC7\u53BB\u4E00\u4E2A\u6708\u4F60\u5BF9\u751F\u6D3B\u4E0D\u53EF\u9884\u6D4B\u3001\u4E0D\u53EF\u63A7\u3001\u8D85\u8D1F\u8377\u7684\u4E3B\u89C2\u611F\u53D7\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\u3002",
    type: "STRESS",
    questions: [
      "\u56E0\u4E3A\u4E00\u4E9B\u610F\u5916\u7684\u4E8B\uFF0C\u60A8\u611F\u5230\u7D27\u5F20\u4E0D\u5B89",
      "\u60A8\u611F\u5230\u5BF9\u751F\u6D3B\u4E2D\u91CD\u8981\u7684\u4E8B\u5931\u53BB\u4E86\u63A7\u5236",
      "\u611F\u5230\u7D27\u5F20\u548C\u538B\u529B",
      "\u60A8\u80FD\u6210\u529F\u5730\u5904\u7406\u607C\u4EBA\u7684\u751F\u6D3B\u9EBB\u70E6",
      "\u60A8\u611F\u5230\u81EA\u5DF1\u80FD\u6709\u6548\u5730\u5E94\u5BF9\u751F\u6D3B\u4E2D\u53D1\u751F\u7684\u91CD\u8981\u53D8\u5316",
      "\u60A8\u611F\u5230\u81EA\u5DF1\u80FD\u5E94\u5BF9\u65E5\u5E38\u4E8B\u52A1",
      "\u60A8\u611F\u5230\u81EA\u5DF1\u80FD\u63A7\u5236\u751F\u6D3B\u4E2D\u4EE4\u4EBA\u607C\u706B\u7684\u4E8B\u60C5",
      "\u60A8\u611F\u5230\u81EA\u5DF1\u80FD\u638C\u63A7\u5168\u5C40",
      "\u60A8\u611F\u5230\u5FC3\u6D6E\u6C14\u8E81\uFF0C\u65E0\u6CD5\u5B89\u9759",
      "\u60A8\u611F\u5230\u56F0\u96BE\u5806\u79EF\u5982\u5C71\uFF0C\u65E0\u6CD5\u514B\u670D"
    ].map((text, i) => ({
      id: `q${i + 1}`,
      text,
      options: OPTS,
      reverse: [3, 4, 5, 6, 7].includes(i)
    })),
    interpretation: {
      bands: [
        { max: 13, level: "\u4F4E\u538B\u529B", advice: "\u611F\u77E5\u538B\u529B\u8F83\u4F4E\uFF0C\u72B6\u6001\u826F\u597D\u3002" },
        { max: 26, level: "\u4E2D\u7B49\u538B\u529B", advice: "\u5B58\u5728\u4E2D\u7B49\u538B\u529B\uFF0C\u5EFA\u8BAE\u589E\u52A0\u653E\u677E\u4E0E\u4F11\u606F\u3002" },
        { max: 40, level: "\u9AD8\u538B\u529B", advice: "\u611F\u77E5\u538B\u529B\u8F83\u9AD8\uFF0C\u5EFA\u8BAE\u5173\u6CE8\u538B\u529B\u7BA1\u7406\u5E76\u5BFB\u6C42\u652F\u6301\u3002" }
      ]
    },
    source: "PSS-10\uFF08Cohen et al. 1983\uFF0C\u516C\u7248\u91CF\u8868\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF09"
  },
  {
    slug: "rses",
    title: "RSES \u81EA\u5C0A\u91CF\u8868\uFF08Rosenberg\uFF09",
    description: "Rosenberg \u81EA\u5C0A\u91CF\u8868\uFF0810 \u9879\uFF09\uFF0C\u6D4B\u91CF\u6574\u4F53\u81EA\u6211\u4EF7\u503C\u611F\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\uFF0C\u4E0D\u6784\u6210\u8BC4\u4F30\u3002",
    type: "SELF_ESTEEM",
    questions: [
      "\u6211\u611F\u5230\u81EA\u5DF1\u662F\u4E00\u4E2A\u6709\u4EF7\u503C\u7684\u4EBA\uFF0C\u81F3\u5C11\u4E0E\u522B\u4EBA\u4E0D\u76F8\u4E0A\u4E0B",
      "\u6211\u89C9\u5F97\u81EA\u5DF1\u6709\u8BB8\u591A\u4F18\u70B9",
      "\u603B\u7684\u6765\u8BF4\uFF0C\u6211\u503E\u5411\u4E8E\u89C9\u5F97\u81EA\u5DF1\u662F\u4E00\u4E2A\u5931\u8D25\u8005",
      "\u6211\u505A\u4E8B\u7684\u80FD\u529B\u5E76\u4E0D\u6BD4\u5927\u591A\u6570\u4EBA\u5DEE",
      "\u6211\u89C9\u5F97\u81EA\u5DF1\u6CA1\u6709\u4EC0\u4E48\u53EF\u81EA\u8C6A\u7684\u5730\u65B9",
      "\u6211\u5BF9\u81EA\u5DF1\u6301\u6709\u4E00\u79CD\u80AF\u5B9A\u7684\u6001\u5EA6",
      "\u6574\u4F53\u800C\u8A00\uFF0C\u6211\u5BF9\u81EA\u5DF1\u611F\u5230\u6EE1\u610F",
      "\u6211\u5E0C\u671B\u6211\u80FD\u66F4\u591A\u5C0A\u91CD\u81EA\u5DF1",
      "\u6709\u65F6\u6211\u7684\u786E\u89C9\u5F97\u81EA\u5DF1\u4E00\u65E0\u662F\u5904",
      "\u6709\u65F6\u6211\u8BA4\u4E3A\u81EA\u5DF1\u4E00\u65E0\u662F\u5904"
    ].map((text, i) => ({
      id: `q${i + 1}`,
      text,
      options: OPTS,
      reverse: [2, 4, 7, 8].includes(i)
    })),
    interpretation: {
      bands: [
        { max: 15, level: "\u8F83\u9AD8\u81EA\u5C0A", advice: "\u81EA\u6211\u4EF7\u503C\u611F\u8F83\u597D\uFF0C\u4FDD\u6301\u3002" },
        { max: 25, level: "\u4E2D\u7B49\u81EA\u5C0A", advice: "\u81EA\u5C0A\u6C34\u5E73\u4E2D\u7B49\uFF0C\u53EF\u591A\u5173\u6CE8\u81EA\u6211\u80AF\u5B9A\u3002" },
        { max: 30, level: "\u504F\u4F4E\u81EA\u5C0A", advice: "\u81EA\u5C0A\u6C34\u5E73\u504F\u4F4E\uFF0C\u5EFA\u8BAE\u901A\u8FC7\u652F\u6301\u6027\u5173\u7CFB\u4E0E\u4E13\u4E1A\u5E2E\u52A9\u63D0\u5347\u3002" }
      ]
    },
    source: "RSES\uFF08Rosenberg 1965\uFF0C\u516C\u7248\u91CF\u8868\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF09"
  },
  {
    slug: "isi",
    title: "ISI \u5931\u7720\u4E25\u91CD\u7A0B\u5EA6\u6307\u6570",
    description: "\u5931\u7720\u4E25\u91CD\u7A0B\u5EA6\u6307\u6570\uFF087 \u9879\uFF09\uFF0C\u5FEB\u901F\u8BC4\u4F30\u5165\u7761\u56F0\u96BE\u3001\u7EF4\u6301\u7761\u7720\u56F0\u96BE\u4E0E\u5BF9\u65E5\u95F4\u529F\u80FD\u7684\u5F71\u54CD\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\u3002",
    type: "SLEEP",
    questions: [
      "\u60A8\u5BF9\u76EE\u524D\u7761\u7720\u6A21\u5F0F\u7684\u4E25\u91CD\u7A0B\u5EA6\u8BC4\u4EF7",
      "\u60A8\u5BF9\u5165\u7761\u56F0\u96BE\u7684\u62B1\u6028\u7A0B\u5EA6",
      "\u60A8\u5BF9\u7EF4\u6301\u7761\u7720\u56F0\u96BE\u7684\u62B1\u6028\u7A0B\u5EA6",
      "\u60A8\u5BF9\u8FC7\u65E9\u9192\u6765\u7684\u62B1\u6028\u7A0B\u5EA6",
      "\u60A8\u5BF9\u76EE\u524D\u7761\u7720\u95EE\u9898\u5BF9\u65E5\u95F4\u529F\u80FD\u7684\u5E72\u6270\u7A0B\u5EA6",
      "\u60A8\u5BF9\u76EE\u524D\u7761\u7720\u95EE\u9898\u5F71\u54CD\u751F\u6D3B\u8D28\u91CF\u7684\u62C5\u5FE7/\u75DB\u82E6\u7A0B\u5EA6",
      "\u60A8\u8BA4\u4E3A\u4ED6\u4EBA\u5BF9\u60A8\u7761\u7720\u95EE\u9898\u7684\u5BDF\u89C9\u7A0B\u5EA6"
    ].map((text, i) => ({ id: `q${i + 1}`, text, options: OPTS })),
    interpretation: {
      bands: [
        { max: 7, level: "\u65E0\u4E34\u5E8A\u610F\u4E49\u5931\u7720", advice: "\u7761\u7720\u8D28\u91CF\u5C1A\u53EF\uFF0C\u4FDD\u6301\u89C4\u5F8B\u4F5C\u606F\u3002" },
        { max: 14, level: "\u9608\u4E0B\u5931\u7720", advice: "\u5B58\u5728\u8F7B\u5EA6\u7761\u7720\u95EE\u9898\uFF0C\u5EFA\u8BAE\u6539\u5584\u7761\u7720\u536B\u751F\u3002" },
        { max: 21, level: "\u4E2D\u5EA6\u5931\u7720", advice: "\u4E2D\u5EA6\u5931\u7720\uFF0C\u5EFA\u8BAE\u5173\u6CE8\u5E76\u54A8\u8BE2\u4E13\u4E1A\u4EBA\u5458\u3002" },
        { max: 28, level: "\u91CD\u5EA6\u5931\u7720", advice: "\u91CD\u5EA6\u5931\u7720\uFF0C\u5EFA\u8BAE\u5C3D\u5FEB\u5BFB\u6C42\u4E13\u4E1A\u8BC4\u4F30\u4E0E\u5E2E\u52A9\u3002" }
      ]
    },
    source: "ISI\uFF08Bastien et al. 2001\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF0C\u6B63\u5F0F\u4F7F\u7528\u8BF7\u83B7\u6388\u6743\uFF09"
  },
  {
    slug: "who-5",
    title: "WHO-5 \u4E94\u7EF4\u5E78\u798F\u611F\u6307\u6570",
    description: "\u4E16\u754C\u536B\u751F\u7EC4\u7EC7\u4E94\u7EF4\u5E78\u798F\u611F\u6307\u6570\uFF085 \u9879\uFF09\uFF0C\u7B80\u77ED\u6D4B\u91CF\u8FD1\u4E24\u5468\u4E3B\u89C2\u5E78\u798F\u611F\uFF0C\u5E38\u7528\u4E8E\u6291\u90C1\u7B5B\u67E5\u8F85\u52A9\u3002\u7ED3\u679C\u4EC5\u4F9B\u53C2\u8003\u3002",
    type: "WELLBEING",
    questions: [
      "\u6211\u611F\u5230\u5FEB\u4E50\u4E14\u5FC3\u60C5\u8212\u7545",
      "\u6211\u611F\u5230\u5E73\u9759\u4E14\u653E\u677E",
      "\u6211\u611F\u5230\u5145\u6EE1\u6D3B\u529B\u4E14\u6709\u7CBE\u795E",
      "\u6211\u9192\u6765\u65F6\u611F\u5230\u4F11\u606F\u5145\u5206\u3001\u7CBE\u529B\u6062\u590D",
      "\u6211\u7684\u65E5\u5E38\u5145\u6EE1\u6709\u8DA3\u7684\u4E8B\u60C5"
    ].map((text, i) => ({ id: `q${i + 1}`, text, options: OPTS })),
    interpretation: {
      bands: [
        { max: 12, level: "\u5E78\u798F\u611F\u826F\u597D", advice: "\u4E3B\u89C2\u5E78\u798F\u611F\u8F83\u597D\uFF0C\u4FDD\u6301\u3002" },
        { max: 14, level: "\u504F\u9AD8", advice: "\u5E78\u798F\u611F\u4E2D\u7B49\uFF0C\u7559\u610F\u60C5\u7EEA\u6CE2\u52A8\u3002" },
        { max: 15, level: "\u9700\u5173\u6CE8", advice: "\u5E78\u798F\u611F\u504F\u4F4E\uFF0C\u5EFA\u8BAE\u589E\u52A0\u79EF\u6781\u6D3B\u52A8\u4E0E\u793E\u4EA4\u652F\u6301\u3002" }
      ]
    },
    source: "WHO-5\uFF08WHO 1998\uFF0C\u516C\u7248\u91CF\u8868\uFF1B\u672C\u5E73\u53F0\u4E3A\u79D1\u666E\u5316\u7B80\u5316\u7248\uFF09"
  }
];
var articles = [
  {
    slug: "what-is-psychology",
    title: "\u4EC0\u4E48\u662F\u5FC3\u7406\u5B66\uFF1F\u4E00\u6587\u8BFB\u61C2\u8FD9\u95E8\u7814\u7A76\u5FC3\u667A\u7684\u79D1\u5B66",
    excerpt: '\u5FC3\u7406\u5B66\u4E0D\u662F"\u8BFB\u5FC3\u672F"\uFF0C\u800C\u662F\u7528\u79D1\u5B66\u65B9\u6CD5\u7814\u7A76\u5FC3\u667A\u4E0E\u884C\u4E3A\u7684\u5B66\u79D1\u3002\u4ECE\u4E34\u5E8A\u5230\u8BA4\u77E5\uFF0C\u672C\u6587\u5E26\u4F60\u5EFA\u7ACB\u6574\u4F53\u8BA4\u77E5\u6846\u67B6\u3002',
    content: "## \u5FC3\u7406\u5B66\u662F\u4EC0\u4E48\n\n\u5FC3\u7406\u5B66\u662F\u7814\u7A76\u5FC3\u667A\u4E0E\u884C\u4E3A\u7684\u79D1\u5B66\uFF0C\u5B83\u4F7F\u7528\u89C2\u5BDF\u3001\u5B9E\u9A8C\u4E0E\u7EDF\u8BA1\u7B49\u79D1\u5B66\u65B9\u6CD5\uFF0C\u800C\u975E\u76F4\u89C9\u6216\u7ECF\u9A8C\u5224\u65AD\u3002\n\n## \u4E3B\u8981\u5206\u652F\n\n\u73B0\u4EE3\u5FC3\u7406\u5B66\u901A\u5E38\u5206\u4E3A\u591A\u4E2A\u5206\u652F\uFF1A\u4E34\u5E8A\u5FC3\u7406\u5B66\u5173\u6CE8\u5FC3\u7406\u969C\u788D\u7684\u8BC4\u4F30\u4E0E\u6CBB\u7597\uFF1B\u54A8\u8BE2\u5FC3\u7406\u5B66\u9762\u5411\u4E00\u822C\u4EBA\u7FA4\u7684\u53D1\u5C55\u4E0E\u9002\u5E94\u95EE\u9898\uFF1B\u8BA4\u77E5\u5FC3\u7406\u5B66\u7814\u7A76\u8BB0\u5FC6\u3001\u6CE8\u610F\u4E0E\u51B3\u7B56\uFF1B\u53D1\u5C55\u5FC3\u7406\u5B66\u8FFD\u8E2A\u4E2A\u4F53\u4E00\u751F\u7684\u53D8\u5316\uFF1B\u793E\u4F1A\u5FC3\u7406\u5B66\u63A2\u8BA8\u4ED6\u4EBA\u5982\u4F55\u5F71\u54CD\u6211\u4EEC\u7684\u60F3\u6CD5\u4E0E\u884C\u4E3A\u3002\n\n## \u5E38\u89C1\u8BEF\u89E3\n\n\u4E00\u4E2A\u5E38\u89C1\u8BEF\u89E3\u662F\u628A\u5FC3\u7406\u5B66\u7B49\u540C\u4E8E\u201C\u8BFB\u5FC3\u201D\u6216\u201C\u7CBE\u795E\u75C5\u9274\u5B9A\u201D\u3002\u4E8B\u5B9E\u4E0A\uFF0C\u7EDD\u5927\u591A\u6570\u5FC3\u7406\u5B66\u7814\u7A76\u670D\u52A1\u4E8E\u6559\u80B2\u3001\u7EC4\u7EC7\u3001\u5065\u5EB7\u4E0E\u516C\u5171\u653F\u7B56\u7B49\u5E7F\u6CDB\u9886\u57DF\u3002\u7406\u89E3\u8FD9\u4E00\u70B9\uFF0C\u80FD\u5E2E\u52A9\u4F60\u66F4\u7406\u6027\u5730\u770B\u5F85\u5404\u7C7B\u5FC3\u7406\u6D4B\u8BC4\u4E0E\u79D1\u666E\u5185\u5BB9\u3002",
    category: "POPSCI",
    tags: ["\u5165\u95E8", "\u5B66\u79D1\u6982\u89C8"],
    sourceName: "\u539F\u521B",
    sourceUrl: "",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-20"
  },
  {
    slug: "depression-self-test-guide",
    title: "\u6291\u90C1\u7B5B\u67E5\u600E\u4E48\u505A\uFF1FPHQ-9 \u4F7F\u7528\u4E0E\u7ED3\u679C\u89E3\u8BFB\u6307\u5357",
    excerpt: "PHQ-9 \u662F\u5168\u7403\u4F7F\u7528\u6700\u5E7F\u7684\u6291\u90C1\u7B5B\u67E5\u91CF\u8868\u4E4B\u4E00\u3002\u672C\u6587\u8BF4\u660E\u5B83\u6D4B\u4EC0\u4E48\u3001\u5206\u6570\u600E\u4E48\u770B\uFF0C\u4EE5\u53CA\u7ED3\u679C\u4E4B\u540E\u8BE5\u505A\u4EC0\u4E48\u3002",
    content: "## PHQ-9 \u6D4B\u4EC0\u4E48\n\nPHQ-9\uFF08\u60A3\u8005\u5065\u5EB7\u95EE\u5377\u6291\u90C1\u91CF\u8868\uFF09\u7531 9 \u4E2A\u6761\u76EE\u7EC4\u6210\uFF0C\u8986\u76D6\u6291\u90C1\u7684\u6838\u5FC3\u75C7\u72B6\uFF0C\u5305\u62EC\u60C5\u7EEA\u3001\u5174\u8DA3\u3001\u7761\u7720\u3001\u98DF\u6B32\u3001\u6CE8\u610F\u529B\u3001\u52A8\u4F5C\u8FDF\u6EDE\u6216\u6FC0\u8D8A\uFF0C\u4EE5\u53CA\u81EA\u4F24\u5FF5\u5934\u3002\u6BCF\u9879\u6309\u8FC7\u53BB\u4E24\u5468\u7684\u9891\u7387\u8BA1 0\u20133 \u5206\uFF0C\u603B\u5206 0\u201327\u3002\n\n## \u5206\u6570\u600E\u4E48\u770B\n\n\u5206\u6570\u4EC5\u4EE3\u8868\u201C\u75C7\u72B6\u8D1F\u8377\u201D\uFF0C\u4E0D\u7B49\u4E8E\u8BCA\u65AD\u3002\u4E00\u822C 0\u20134 \u5206\u5C5E\u6781\u8F7B\u5FAE\uFF0C5 \u5206\u4EE5\u4E0A\u63D0\u793A\u9700\u8981\u5173\u6CE8\uFF0C10 \u5206\u4EE5\u4E0A\u5EFA\u8BAE\u5BFB\u6C42\u4E13\u4E1A\u5E2E\u52A9\uFF0C15 \u5206\u4EE5\u4E0A\u66F4\u5E94\u5C3D\u5FEB\u8BC4\u4F30\u3002\u7B2C 9 \u9898\uFF08\u81EA\u4F24\u5FF5\u5934\uFF09\u65E0\u8BBA\u603B\u5206\u591A\u5C11\u90FD\u9700\u8BA4\u771F\u5BF9\u5F85\u3002\n\n## \u7ED3\u679C\u4E4B\u540E\u8BE5\u505A\u4EC0\u4E48\n\n\u91CD\u8981\u63D0\u9192\uFF1A\u7B5B\u67E5\u91CF\u8868\u4E0D\u80FD\u66FF\u4EE3\u533B\u751F\u6216\u5FC3\u7406\u6CBB\u7597\u5E08\u7684\u4E34\u5E8A\u8BBF\u8C08\u3002\u5982\u679C\u4F60\u6216\u8EAB\u8FB9\u4EBA\u51FA\u73B0\u6301\u7EED\u4E24\u5468\u4EE5\u4E0A\u7684\u4F4E\u843D\u3001\u5174\u8DA3\u4E27\u5931\u6216\u529F\u80FD\u4E0B\u964D\uFF0C\u8BF7\u53CA\u65F6\u8054\u7CFB\u4E13\u4E1A\u673A\u6784\u6216\u5371\u673A\u70ED\u7EBF\u3002",
    category: "POPSCI",
    tags: ["\u6291\u90C1", "PHQ-9", "\u7B5B\u67E5"],
    sourceName: "\u539F\u521B\uFF08\u53C2\u8003 APA / NIMH \u516C\u5F00\u8D44\u6599\uFF09",
    sourceUrl: "https://www.nimh.nih.gov",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-21"
  },
  {
    slug: "anxiety-coping",
    title: "\u7126\u8651\u6765\u88AD\u65F6\uFF0C\u4F60\u53EF\u4EE5\u8BD5\u8BD5\u7684 6 \u4E2A\u79D1\u5B66\u65B9\u6CD5",
    excerpt: "\u7126\u8651\u662F\u8EAB\u4F53\u7684\u6B63\u5E38\u8B66\u62A5\uFF0C\u4F46\u6301\u7EED\u8FC7\u9AD8\u4F1A\u6D88\u8017\u4F60\u3002\u4E0B\u9762 6 \u4E2A\u57FA\u4E8E\u8BC1\u636E\u7684\u65B9\u6CD5\uFF0C\u80FD\u5E2E\u52A9\u4F60\u5728\u5F53\u4E0B\u56DE\u5230\u638C\u63A7\u611F\u3002",
    content: "## \u5F53\u4E0B\u53EF\u4EE5\u505A\u7684 6 \u4E2A\u65B9\u6CD5\n\n1. \u547C\u5438\u8C03\u8282\uFF1A\u5C1D\u8BD5 4-7-8 \u547C\u5438\uFF08\u5438\u6C14 4 \u79D2\u3001\u5C4F\u606F 7 \u79D2\u3001\u547C\u6C14 8 \u79D2\uFF09\uFF0C\u6FC0\u6D3B\u526F\u4EA4\u611F\u795E\u7ECF\uFF0C\u964D\u4F4E\u751F\u7406\u5524\u9192\u3002\n\n2. \u7740\u9646\u7EC3\u4E60\uFF1A\u8BF4\u51FA\u4F60\u770B\u5230\u7684 5 \u6837\u4E1C\u897F\u3001\u542C\u5230\u7684 4 \u79CD\u58F0\u97F3\u3001\u80FD\u89E6\u6478\u7684 3 \u6837\u7269\u4F53\uFF0C\u628A\u6CE8\u610F\u529B\u4ECE\u201C\u707E\u96BE\u5316\u60F3\u8C61\u201D\u62C9\u56DE\u5F53\u4E0B\u3002\n\n3. \u547D\u540D\u60C5\u7EEA\uFF1A\u7528\u5177\u4F53\u8BCD\u6C47\u63CF\u8FF0\u611F\u53D7\uFF08\u201C\u8FD9\u662F\u7D27\u5F20\uFF0C\u4E0D\u662F\u5371\u9669\u201D\uFF09\uFF0C\u80FD\u964D\u4F4E\u674F\u4EC1\u6838\u7684\u8FC7\u5EA6\u53CD\u5E94\u3002\n\n4. \u9650\u5236\u523A\u6FC0\uFF1A\u6682\u65F6\u8FDC\u79BB\u793E\u4EA4\u5A92\u4F53\u4E0E\u8D1F\u9762\u4FE1\u606F\u6E90\uFF0C\u7ED9\u5927\u8111\u4F11\u606F\u7A97\u53E3\u3002\n\n5. \u8EAB\u4F53\u6D3B\u52A8\uFF1A10 \u5206\u949F\u5FEB\u8D70\u53EF\u4FC3\u8FDB\u5185\u5561\u80BD\u91CA\u653E\uFF0C\u6539\u5584\u60C5\u7EEA\u3002\n\n6. \u89C4\u5F8B\u4F5C\u606F\uFF1A\u7761\u7720\u77ED\u7F3A\u4F1A\u663E\u8457\u653E\u5927\u7126\u8651\uFF0C\u56FA\u5B9A\u4F5C\u606F\u662F\u6700\u4FBF\u5B9C\u7684\u201C\u6297\u7126\u8651\u836F\u201D\u3002\n\n## \u4EC0\u4E48\u65F6\u5019\u8BE5\u5BFB\u6C42\u4E13\u4E1A\u5E2E\u52A9\n\n\u5982\u679C\u7126\u8651\u9891\u7E41\u51FA\u73B0\u5E76\u5F71\u54CD\u5DE5\u4F5C\u4E0E\u751F\u6D3B\uFF0C\u5EFA\u8BAE\u901A\u8FC7\u672C\u5E73\u53F0\u7684\u6D4B\u8BC4\u5DE5\u5177\u5148\u505A\u81EA\u8BC4\uFF0C\u518D\u8003\u8651\u5BFB\u6C42\u4E13\u4E1A\u652F\u6301\u3002",
    category: "POPSCI",
    tags: ["\u7126\u8651", "\u81EA\u52A9", "\u60C5\u7EEA\u8C03\u8282"],
    sourceName: "\u539F\u521B",
    sourceUrl: "",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-22"
  },
  {
    slug: "how-to-find-therapist",
    title: "\u5982\u4F55\u6311\u9009\u5408\u9002\u7684\u5FC3\u7406\u54A8\u8BE2\u5E08\uFF1F\u7ED9\u65B0\u624B\u7684 7 \u6761\u5EFA\u8BAE",
    excerpt: "\u7B2C\u4E00\u6B21\u627E\u54A8\u8BE2\u5BB9\u6613\u8E29\u5751\u3002\u4ECE\u8D44\u8D28\u3001\u6D41\u6D3E\u5230\u521D\u59CB\u8BBF\u8C08\uFF0C\u672C\u6587\u5E2E\u4F60\u5EFA\u7ACB\u7B5B\u9009\u6846\u67B6\u3002",
    content: "## \u65B0\u624B\u7B5B\u9009\u6846\u67B6\n\n1. \u770B\u8D44\u8D28\uFF1A\u4F18\u5148\u9009\u62E9\u6301\u6709\u56FD\u5BB6\u5FC3\u7406\u54A8\u8BE2\u5E08/\u6CBB\u7597\u5E08\u76F8\u5173\u8D44\u8D28\u3001\u6216\u5FC3\u7406\u5B66/\u7CBE\u795E\u533B\u5B66\u4E13\u4E1A\u80CC\u666F\u7684\u4ECE\u4E1A\u8005\u3002\n\n2. \u770B\u6D41\u6D3E\uFF1A\u8BA4\u77E5\u884C\u4E3A\u7597\u6CD5\uFF08CBT\uFF09\u3001\u4EBA\u672C\u4E3B\u4E49\u3001\u7CBE\u795E\u52A8\u529B\u5B66\u5404\u6709\u4FA7\u91CD\uFF0C\u53EF\u5148\u4E86\u89E3\u518D\u5339\u914D\u81EA\u5DF1\u7684\u8BAE\u9898\u3002\n\n3. \u521D\u59CB\u8BBF\u8C08\uFF1A\u591A\u6570\u54A8\u8BE2\u5E08\u63D0\u4F9B\u4F4E\u4EF7\u6216\u514D\u8D39\u7684\u521D\u59CB\u8BBF\u8C08\uFF0C\u7528\u6765\u5224\u65AD\u201C\u6C14\u573A\u5408\u4E0D\u5408\u201D\u3002\n\n4. \u8BAE\u9898\u5339\u914D\uFF1A\u6291\u90C1\u3001\u7126\u8651\u3001\u5173\u7CFB\u3001\u521B\u4F24\u5404\u6709\u64C5\u957F\u7684\u54A8\u8BE2\u5E08\uFF0C\u522B\u4E0D\u597D\u610F\u601D\u95EE\u5BF9\u65B9\u7ECF\u9A8C\u3002\n\n5. \u8BBE\u7F6E\u4E0E\u8FB9\u754C\uFF1A\u660E\u786E\u8D39\u7528\u3001\u9891\u7387\u3001\u53D6\u6D88\u653F\u7B56\u4E0E\u4FDD\u5BC6\u8303\u56F4\uFF0C\u907F\u514D\u540E\u7EED\u7EA0\u7EB7\u3002\n\n6. \u76F8\u4FE1\u611F\u53D7\uFF1A\u5982\u679C\u51E0\u6B21\u4E4B\u540E\u4ECD\u611F\u5230\u88AB\u8BC4\u5224\u6216\u4E0D\u5B89\u5168\uFF0C\u6362\u4EBA\u662F\u6B63\u5E38\u7684\u3002\n\n7. \u5584\u7528\u8F6C\u4ECB\uFF1A\u4E25\u91CD\u60C5\u51B5\uFF08\u5982\u81EA\u4F24\u98CE\u9669\uFF09\u5E94\u53CA\u65F6\u8F6C\u4ECB\u7CBE\u795E\u79D1\uFF0C\u54A8\u8BE2\u4E0E\u836F\u7269\u5E76\u4E0D\u4E92\u65A5\u3002\n\n## \u8D77\u6B65\u5EFA\u8BAE\n\n\u672C\u5E73\u53F0\u7684\u201C\u8D44\u6E90\u5BFC\u822A\u201D\u6536\u5F55\u4E86\u5168\u7403\u4F18\u8D28\u54A8\u8BE2\u4E0E\u6CBB\u7597\u5E73\u53F0\uFF0C\u53EF\u4F5C\u4E3A\u8D77\u6B65\u53C2\u8003\u3002",
    category: "POPSCI",
    tags: ["\u54A8\u8BE2", "\u6307\u5357", "\u65B0\u624B"],
    sourceName: "\u539F\u521B",
    sourceUrl: "",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-22"
  },
  {
    slug: "sleep-and-mental-health",
    title: "\u7761\u7720\u4E0E\u5FC3\u7406\u5065\u5EB7\u7684\u53CC\u5411\u5173\u7CFB",
    excerpt: "\u7761\u4E0D\u597D\u4F1A\u52A0\u91CD\u60C5\u7EEA\u95EE\u9898\uFF0C\u60C5\u7EEA\u95EE\u9898\u4E5F\u4F1A\u53CD\u8FC7\u6765\u6270\u4E71\u7761\u7720\u3002\u7406\u89E3\u8FD9\u6761\u53CC\u5411\u901A\u9053\uFF0C\u662F\u81EA\u6211\u7167\u62A4\u7684\u7B2C\u4E00\u6B65\u3002",
    content: "## \u7761\u7720\u4E0E\u60C5\u7EEA\u7684\u53CC\u5411\u5173\u7CFB\n\n\u7761\u7720\u4E0E\u5FC3\u7406\u5065\u5EB7\u4E4B\u95F4\u5B58\u5728\u53CC\u5411\u5173\u7CFB\u3002\u4E00\u65B9\u9762\uFF0C\u5931\u7720\u3001\u65E9\u9192\u7B49\u7761\u7720\u95EE\u9898\u662F\u6291\u90C1\u548C\u7126\u8651\u7684\u5E38\u89C1\u524D\u9A71\u4E0E\u4F34\u968F\u75C7\u72B6\uFF1B\u53E6\u4E00\u65B9\u9762\uFF0C\u957F\u671F\u7761\u7720\u5265\u593A\u4F1A\u524A\u5F31\u60C5\u7EEA\u8C03\u8282\u80FD\u529B\uFF0C\u653E\u5927\u538B\u529B\u53CD\u5E94\u3002\n\n## \u7761\u7720\u536B\u751F\u8981\u70B9\n\n\u7814\u7A76\u6307\u51FA\uFF0C\u89C4\u5F8B\u4F5C\u606F\u3001\u56FA\u5B9A\u8D77\u5E8A\u65F6\u95F4\u6BD4\u201C\u7761\u591F\u65F6\u957F\u201D\u66F4\u80FD\u7A33\u5B9A\u751F\u7269\u949F\u3002\u7761\u524D 1 \u5C0F\u65F6\u51CF\u5C11\u84DD\u5149\u66B4\u9732\u3001\u4FDD\u6301\u5367\u5BA4\u51C9\u723D\u9ED1\u6697\uFF0C\u662F\u88AB\u53CD\u590D\u9A8C\u8BC1\u7684\u7761\u7720\u536B\u751F\u8981\u70B9\u3002\n\n## \u4F55\u65F6\u5BFB\u6C42\u5E2E\u52A9\n\n\u5982\u679C\u4F60\u957F\u671F\u53D7\u7761\u7720\u56F0\u6270\uFF0C\u53EF\u5148\u7528\u672C\u5E73\u53F0\u7684 ISI \u5931\u7720\u4E25\u91CD\u7A0B\u5EA6\u6D4B\u8BC4\u505A\u521D\u6B65\u81EA\u8BC4\uFF0C\u5FC5\u8981\u65F6\u5BFB\u6C42\u7761\u7720\u95E8\u8BCA\u6216\u5FC3\u7406\u6CBB\u7597\uFF08\u5982 CBT-I\uFF09\u7684\u4E13\u4E1A\u5E2E\u52A9\u3002",
    category: "RESEARCH",
    tags: ["\u7761\u7720", "\u7814\u7A76", "\u60C5\u7EEA"],
    sourceName: "\u539F\u521B\uFF08\u7EFC\u5408 NIMH / \u7761\u7720\u533B\u5B66\u7EFC\u8FF0\uFF09",
    sourceUrl: "https://www.nimh.nih.gov",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-23"
  },
  {
    slug: "psychology-of-social-media",
    title: "\u793E\u4EA4\u5A92\u4F53\u771F\u7684\u8BA9\u4EBA\u66F4\u5B64\u72EC\u5417\uFF1F\u7814\u7A76\u600E\u4E48\u8BF4",
    excerpt: '"\u8D8A\u5237\u8D8A\u5B64\u72EC"\u5E76\u975E\u9519\u89C9\u3002\u7814\u7A76\u63ED\u793A\u4E86\u88AB\u52A8\u6D4F\u89C8\u4E0E\u4E3B\u52A8\u4E92\u52A8\u622A\u7136\u4E0D\u540C\u7684\u5FC3\u7406\u540E\u679C\u3002',
    content: "## \u4E24\u79CD\u4F7F\u7528\u65B9\u5F0F\n\n\u591A\u9879\u7814\u7A76\u533A\u5206\u4E86\u793E\u4EA4\u5A92\u4F53\u7684\u4E24\u79CD\u4F7F\u7528\u65B9\u5F0F\uFF1A\u88AB\u52A8\u6D4F\u89C8\uFF08\u5237\u4FE1\u606F\u6D41\u800C\u4E0D\u4E92\u52A8\uFF09\u4E0E\u4E3B\u52A8\u4E92\u52A8\uFF08\u8BC4\u8BBA\u3001\u79C1\u4FE1\u3001\u7EF4\u6301\u5173\u7CFB\uFF09\u3002\u524D\u8005\u4E0E\u5B64\u72EC\u611F\u548C\u60C5\u7EEA\u4F4E\u843D\u66F4\u76F8\u5173\uFF0C\u540E\u8005\u5219\u53EF\u80FD\u589E\u5F3A\u793E\u4F1A\u652F\u6301\u3002\n\n## \u4E0A\u884C\u793E\u4F1A\u6BD4\u8F83\u7684\u9677\u9631\n\n\u4E00\u4E2A\u5173\u952E\u673A\u5236\u662F\u201C\u4E0A\u884C\u793E\u4F1A\u6BD4\u8F83\u201D\u2014\u2014\u770B\u5230\u4ED6\u4EBA\u7CBE\u5FC3\u7B5B\u9009\u7684\u9AD8\u5149\u65F6\u523B\uFF0C\u5BB9\u6613\u4EA7\u751F\u201C\u53EA\u6709\u6211\u8FC7\u5F97\u4E0D\u597D\u201D\u7684\u9519\u89C9\u3002\u6B64\u5916\uFF0C\u7B97\u6CD5\u63A8\u8350\u4F1A\u653E\u5927\u60C5\u7EEA\u5316\u5185\u5BB9\uFF0C\u5F62\u6210\u8D1F\u9762\u5FAA\u73AF\u3002\n\n## \u5B9E\u7528\u5EFA\u8BAE\n\n\u628A\u201C\u5237\u201D\u6539\u4E3A\u201C\u804A\u201D\uFF0C\u7ED9\u6BCF\u5468\u8BBE\u5B9A\u65E0\u793E\u4EA4\u5A92\u4F53\u7684\u65F6\u6BB5\uFF0C\u5E76\u8B66\u60D5\u7528\u5E73\u53F0\u5185\u5BB9\u66FF\u4EE3\u771F\u5B9E\u5173\u7CFB\u3002\u82E5\u4F7F\u7528\u793E\u4EA4\u5A92\u4F53\u660E\u663E\u5F71\u54CD\u60C5\u7EEA\uFF0C\u51CF\u5C11\u65F6\u957F\u672C\u8EAB\u5C31\u662F\u4E00\u79CD\u5E72\u9884\u3002",
    category: "RESEARCH",
    tags: ["\u793E\u4EA4\u5A92\u4F53", "\u7814\u7A76", "\u5B64\u72EC"],
    sourceName: "\u539F\u521B\uFF08\u7EFC\u5408\u793E\u4F1A\u5FC3\u7406\u5B66\u7814\u7A76\uFF09",
    sourceUrl: "",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-23"
  },
  {
    slug: "free-mental-health-resources-china",
    title: "\u56FD\u5185\u53EF\u7528\u7684\u514D\u8D39\u5FC3\u7406\u6C42\u52A9\u8D44\u6E90\u6C47\u603B",
    excerpt: '\u5371\u673A\u65F6\u523B\u4E0D\u8BE5\u56E0\u4E3A"\u4E0D\u77E5\u9053\u53BB\u54EA"\u800C\u803D\u8BEF\u3002\u672C\u6587\u6C47\u603B\u56FD\u5185\u514D\u8D39\u3001\u53EF\u53CA\u7684\u5FC3\u7406\u6C42\u52A9\u5165\u53E3\u3002',
    content: "## \u514D\u8D39\u5FC3\u7406\u6C42\u52A9\u70ED\u7EBF\n\n\u56FD\u5185\u5DF2\u6709\u591A\u6761\u514D\u8D39\u5FC3\u7406\u6C42\u52A9\u70ED\u7EBF\uFF0C\u9762\u5411\u4E0D\u540C\u4EBA\u7FA4\uFF1A\u5168\u56FD\u5FC3\u7406\u5371\u673A\u5E72\u9884\u70ED\u7EBF\uFF08400-161-9995\uFF0C\u5E0C\u671B24\u70ED\u7EBF\uFF09\u3001\u5317\u4EAC\u5FC3\u7406\u63F4\u52A9\u70ED\u7EBF\uFF08010-82951332\uFF09\u7B49\uFF0C\u63D0\u4F9B 24 \u5C0F\u65F6\u7684\u60C5\u7EEA\u652F\u6301\u4E0E\u5371\u673A\u5E72\u9884\u3002\n\n## \u5176\u4ED6\u4F4E\u4EF7\u6C42\u52A9\u6E20\u9053\n\n\u9664\u70ED\u7EBF\u5916\uFF0C\u90E8\u5206\u7701\u5E02\u7CBE\u795E\u536B\u751F\u4E2D\u5FC3\u3001\u9AD8\u6821\u5FC3\u7406\u54A8\u8BE2\u4E2D\u5FC3\u4E0E\u516C\u76CA\u7EC4\u7EC7\u4E5F\u63D0\u4F9B\u4F4E\u4EF7\u6216\u514D\u8D39\u7684\u521D\u6B65\u8BC4\u4F30\u4E0E\u758F\u5BFC\u3002\u9047\u5230\u7D27\u6025\u81EA\u4F24\u98CE\u9669\u65F6\uFF0C\u8BF7\u4F18\u5148\u62E8\u6253\u5371\u673A\u70ED\u7EBF\u6216\u524D\u5F80\u6700\u8FD1\u533B\u9662\u6025\u8BCA\u3002\n\n## \u63D0\u524D\u6536\u85CF\n\n\u672C\u5E73\u53F0\u201C\u6C42\u52A9\u8D44\u6E90\u201D\u680F\u76EE\u6301\u7EED\u6C47\u603B\u4E2D\u56FD\u53CA\u5168\u7403\u5371\u673A\u5E72\u9884\u3001\u652F\u6301\u4E0E\u4F4E\u4EF7\u6C42\u52A9\u6E20\u9053\uFF0C\u5EFA\u8BAE\u63D0\u524D\u6536\u85CF\uFF0C\u5173\u952E\u65F6\u523B\u7528\u5F97\u4E0A\u3002",
    category: "NEWS",
    tags: ["\u6C42\u52A9", "\u4E2D\u56FD", "\u8D44\u6E90", "\u70ED\u7EBF"],
    sourceName: "\u539F\u521B",
    sourceUrl: "",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-24"
  },
  {
    slug: "understanding-burnout",
    title: "\u5026\u6020\u4E0D\u662F\u77EB\u60C5\uFF1A\u8BA4\u8BC6\u804C\u4E1A\u5026\u6020\u7684 3 \u4E2A\u7EF4\u5EA6",
    excerpt: "\u804C\u4E1A\u5026\u6020\u5DF2\u88AB WHO \u5217\u5165\u56FD\u9645\u75BE\u75C5\u5206\u7C7B\u3002\u5B83\u6709\u4E09\u4E2A\u53EF\u8BC6\u522B\u7684\u7EF4\u5EA6\uFF0C\u5E2E\u52A9\u4F60\u53CA\u65E9\u8BC6\u522B\u800C\u975E\u786C\u625B\u3002",
    content: "## \u4EC0\u4E48\u662F\u804C\u4E1A\u5026\u6020\n\n\u4E16\u754C\u536B\u751F\u7EC4\u7EC7\u5C06\u804C\u4E1A\u5026\u6020\u5B9A\u4E49\u4E3A\u201C\u957F\u671F\u672A\u6210\u529F\u7BA1\u7406\u7684\u804C\u573A\u538B\u529B\u201D\u73B0\u8C61\uFF0C\u5305\u542B\u4E09\u4E2A\u7EF4\u5EA6\uFF1A\u60C5\u7EEA\u8017\u7AED\uFF08\u611F\u5230\u7CBE\u529B\u88AB\u638F\u7A7A\uFF09\u3001\u53BB\u4EBA\u683C\u5316/\u758F\u79BB\uFF08\u5BF9\u5DE5\u4F5C\u548C\u4ED6\u4EBA\u53D8\u5F97\u51B7\u6F20\u6577\u884D\uFF09\u3001\u4EE5\u53CA\u4E2A\u4EBA\u6210\u5C31\u611F\u964D\u4F4E\u3002\n\n## \u5026\u6020\u4E0E\u666E\u901A\u75B2\u52B3\u7684\u533A\u522B\n\n\u5026\u6020\u4E0E\u666E\u901A\u75B2\u52B3\u7684\u533A\u522B\u5728\u4E8E\uFF1A\u4F11\u606F\u540E\u96BE\u4EE5\u6062\u590D\uFF0C\u4E14\u4F34\u968F\u5BF9\u5DE5\u4F5C\u7684\u6D88\u6781\u6001\u5EA6\u8F6C\u53D8\u3002\u9AD8\u5371\u4EBA\u7FA4\u5305\u62EC\u52A9\u4EBA\u884C\u4E1A\uFF08\u533B\u62A4\u3001\u6559\u5E08\u3001\u54A8\u8BE2\u5E08\uFF09\u3001\u9AD8\u8D1F\u8377\u4E92\u8054\u7F51\u4ECE\u4E1A\u8005\u3002\n\n## \u5982\u4F55\u5E94\u5BF9\n\n\u5E94\u5BF9\u4E0A\uFF0C\u5355\u9760\u201C\u591A\u4F11\u606F\u201D\u5F80\u5F80\u4E0D\u591F\uFF0C\u9700\u8981\u5BA1\u89C6\u63A7\u5236\u611F\u3001\u4EF7\u503C\u611F\u4E0E\u8FB9\u754C\u3002\u82E5\u5DF2\u660E\u663E\u5F71\u54CD\u5065\u5EB7\uFF0C\u53EF\u7ED3\u5408\u672C\u5E73\u53F0\u7684\u538B\u529B\u4E0E\u60C5\u7EEA\u6D4B\u8BC4\u505A\u81EA\u8BC4\uFF0C\u5E76\u8003\u8651\u8C03\u6574\u5DE5\u4F5C\u6216\u5BFB\u6C42\u652F\u6301\u3002",
    category: "POPSCI",
    tags: ["\u5026\u6020", "\u804C\u573A", "\u538B\u529B"],
    sourceName: "\u539F\u521B\uFF08\u53C2\u8003 WHO \u516C\u5F00\u5B9A\u4E49\uFF09",
    sourceUrl: "https://www.who.int",
    author: "\u5FC3\u7406\u8D44\u6E90\u805A\u5408\u7F16\u8F91\u90E8",
    publishedAt: "2026-07-24"
  }
];
var counselors = [
  {
    id: "c-lin-zhi",
    name: "\u6797\u77E5",
    title: "\u56FD\u5BB6\u4E8C\u7EA7\u5FC3\u7406\u54A8\u8BE2\u5E08",
    specialties: ["\u6291\u90C1", "\u7126\u8651", "\u60C5\u7EEA\u8C03\u8282"],
    approach: ["CBT", "\u4EBA\u672C\u4E3B\u4E49"],
    region: "\u5317\u4EAC",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 500,
    currency: "CNY",
    org: "\u5317\u4EAC\u5B89\u5FC3\u5FC3\u7406\u54A8\u8BE2\u4E2D\u5FC3",
    bio: "\u4E13\u6CE8\u4E8E\u6291\u90C1\u4E0E\u7126\u8651\u7684\u8BA4\u77E5\u884C\u4E3A\u5E72\u9884\uFF0C\u64C5\u957F\u5E2E\u52A9\u9752\u58EE\u5E74\u5EFA\u7ACB\u60C5\u7EEA\u8C03\u8282\u7684\u65E5\u5E38\u5DE5\u5177\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-lin-zhi",
    rating: 4.8,
    yearsExperience: 8,
    tags: ["\u8BA4\u77E5\u884C\u4E3A", "\u9752\u5E74"],
    featured: true
  },
  {
    id: "c-su-wan",
    name: "\u82CF\u665A",
    title: "\u6CE8\u518C\u5FC3\u7406\u5E08\uFF08\u4F34\u4FA3\u4E0E\u5BB6\u5EAD\uFF09",
    specialties: ["\u4EB2\u5BC6\u5173\u7CFB", "\u5A5A\u59FB\u5BB6\u5EAD", "\u4EB2\u5B50"],
    approach: ["\u7CFB\u7EDF\u5F0F\u5BB6\u5EAD\u6CBB\u7597", "EFT"],
    region: "\u4E0A\u6D77",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 600,
    currency: "CNY",
    org: "\u4E0A\u6D77\u5B81\u5FC3\u5FC3\u7406\u54A8\u8BE2",
    bio: "\u805A\u7126\u5A5A\u604B\u4E0E\u5BB6\u5EAD\u8BAE\u9898\uFF0C\u5E2E\u52A9\u4F34\u4FA3\u6539\u5584\u6C9F\u901A\u4E0E\u51B2\u7A81\u6A21\u5F0F\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-su-wan",
    rating: 4.9,
    yearsExperience: 11,
    tags: ["\u5BB6\u5EAD", "\u6C9F\u901A"],
    featured: true
  },
  {
    id: "c-chen-yu",
    name: "\u9648\u5C7F",
    title: "\u4E34\u5E8A\u5FC3\u7406\u5B66\u7855\u58EB",
    specialties: ["\u521B\u4F24", "PTSD", "\u7126\u8651"],
    approach: ["EMDR", "\u7CBE\u795E\u52A8\u529B\u5B66"],
    region: "\u5E7F\u5DDE",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 550,
    currency: "CNY",
    org: "\u5E7F\u5DDE\u6674\u7A7A\u5FC3\u7406\u5DE5\u4F5C\u5BA4",
    bio: "\u4ECE\u4E8B\u521B\u4F24\u4E0E\u521B\u4F24\u540E\u5E94\u6FC0\u7684\u76F8\u5173\u5DE5\u4F5C\uFF0C\u63D0\u4F9B\u7A33\u5B9A\u5316\u4E0E\u521B\u4F24\u805A\u7126\u5E72\u9884\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-chen-yu",
    rating: 4.7,
    yearsExperience: 9,
    tags: ["\u521B\u4F24", "EMDR"],
    featured: true
  },
  {
    id: "c-he-chuan",
    name: "\u4F55\u5DDD",
    title: "\u5FC3\u7406\u54A8\u8BE2\u5E08",
    specialties: ["\u804C\u4E1A\u5026\u6020", "\u538B\u529B", "\u7761\u7720"],
    approach: ["CBT", "\u6B63\u5FF5"],
    region: "\u6DF1\u5733",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 480,
    currency: "CNY",
    org: "\u6DF1\u5733\u77E5\u9047\u5FC3\u7406",
    bio: "\u9762\u5411\u9AD8\u538B\u804C\u4E1A\u4EBA\u7FA4\uFF0C\u7ED3\u5408\u8BA4\u77E5\u884C\u4E3A\u4E0E\u65F6\u4E0B\u6B63\u5FF5\u7EC3\u4E60\u7F13\u89E3\u5026\u6020\u4E0E\u5931\u7720\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-he-chuan",
    rating: 4.6,
    yearsExperience: 6,
    tags: ["\u804C\u573A", "\u6B63\u5FF5"],
    featured: false
  },
  {
    id: "c-luo-yu",
    name: "\u7F57\u4E88",
    title: "\u56FD\u5BB6\u4E09\u7EA7\u5FC3\u7406\u54A8\u8BE2\u5E08",
    specialties: ["\u9752\u5C11\u5E74", "\u5B66\u4E1A\u538B\u529B", "\u540C\u4F34\u5173\u7CFB"],
    approach: ["\u4EBA\u672C\u4E3B\u4E49", "\u6E38\u620F\u6CBB\u7597"],
    region: "\u6210\u90FD",
    remote: false,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 400,
    currency: "CNY",
    org: "\u6210\u90FD\u5C0F\u6811\u82D7\u5FC3\u7406",
    bio: "\u9762\u5411\u513F\u7AE5\u4E0E\u9752\u5C11\u5E74\uFF0C\u4EE5\u6E29\u548C\u7684\u6E38\u620F\u4E0E\u4EBA\u672C\u65B9\u5F0F\u966A\u4F34\u6210\u957F\u8BAE\u9898\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-luo-yu",
    rating: 4.7,
    yearsExperience: 7,
    tags: ["\u9752\u5C11\u5E74", "\u5BB6\u5EAD"],
    featured: false
  },
  {
    id: "c-jiang-lin",
    name: "\u6C5F\u4E34",
    title: "\u5FC3\u7406\u52A8\u529B\u5B66\u53D6\u5411\u54A8\u8BE2\u5E08",
    specialties: ["\u81EA\u6211\u63A2\u7D22", "\u5B58\u5728\u7126\u8651", "\u4EB2\u5BC6\u5173\u7CFB"],
    approach: ["\u7CBE\u795E\u52A8\u529B\u5B66"],
    region: "\u676D\u5DDE",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 680,
    currency: "CNY",
    org: "\u676D\u5DDE\u542C\u6D77\u5FC3\u7406\u54A8\u8BE2",
    bio: "\u957F\u7A0B\u5FC3\u7406\u52A8\u529B\u5B66\u5DE5\u4F5C\uFF0C\u9002\u5408\u5E0C\u671B\u6DF1\u5165\u7406\u89E3\u81EA\u8EAB\u6A21\u5F0F\u3001\u8FDB\u884C\u81EA\u6211\u63A2\u7D22\u7684\u6765\u8BBF\u8005\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-jiang-lin",
    rating: 4.8,
    yearsExperience: 12,
    tags: ["\u957F\u7A0B", "\u81EA\u6211\u6210\u957F"],
    featured: true
  },
  {
    id: "c-wei-an",
    name: "\u97E6\u5CB8",
    title: "\u5A5A\u59FB\u4E0E\u5BB6\u5EAD\u6CBB\u7597\u5E08",
    specialties: ["\u5A5A\u59FB", "\u5BB6\u5EAD", "\u6C9F\u901A"],
    approach: ["\u7CFB\u7EDF\u5F0F", "EFT"],
    region: "\u5317\u4EAC",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 720,
    currency: "CNY",
    org: "\u5317\u4EAC\u4F34\u4FA3\u5DE5\u4F5C\u5BA4",
    bio: "\u4E0E\u4F34\u4FA3\u53CA\u5BB6\u5EAD\u4E00\u540C\u5DE5\u4F5C\uFF0C\u6539\u5584\u4E92\u52A8\u5FAA\u73AF\u4E0E\u4F9D\u604B\u5B89\u5168\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-wei-an",
    rating: 4.9,
    yearsExperience: 14,
    tags: ["\u5BB6\u5EAD", "\u4F34\u4FA3"],
    featured: false
  },
  {
    id: "c-gu-yuan",
    name: "\u987E\u8FDC",
    title: "\u6210\u763E\u884C\u4E3A\u5FC3\u7406\u54A8\u8BE2\u5E08",
    specialties: ["\u6210\u763E", "\u51B2\u52A8\u63A7\u5236", "\u7F51\u7EDC\u4F9D\u8D56"],
    approach: ["CBT", "\u52A8\u673A\u8BBF\u8C08"],
    region: "\u6B66\u6C49",
    remote: false,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 520,
    currency: "CNY",
    org: "\u6B66\u6C49\u6E05\u6E90\u5FC3\u7406",
    bio: "\u805A\u7126\u884C\u4E3A\u6210\u763E\u4E0E\u51B2\u52A8\u63A7\u5236\uFF0C\u7ED3\u5408\u52A8\u673A\u8BBF\u8C08\u964D\u4F4E\u590D\u53D1\u98CE\u9669\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-gu-yuan",
    rating: 4.5,
    yearsExperience: 8,
    tags: ["\u6210\u763E", "\u884C\u4E3A"],
    featured: false
  },
  {
    id: "c-shao-ning",
    name: "\u90B5\u5B81",
    title: "\u8001\u5E74\u5FC3\u7406\u5173\u6000\u54A8\u8BE2\u5E08",
    specialties: ["\u8001\u5E74\u5FC3\u7406", "\u4E27\u4EB2", "\u5B64\u72EC"],
    approach: ["\u4EBA\u672C\u4E3B\u4E49", "\u56DE\u5FC6\u7597\u6CD5"],
    region: "\u5357\u4EAC",
    remote: false,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 380,
    currency: "CNY",
    org: "\u5357\u4EAC\u6696\u9633\u5FC3\u7406",
    bio: "\u966A\u4F34\u957F\u8005\u9762\u5BF9\u5B64\u72EC\u3001\u4E27\u4EB2\u4E0E\u751F\u547D\u9636\u6BB5\u7684\u8F6C\u6362\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-shao-ning",
    rating: 4.7,
    yearsExperience: 10,
    tags: ["\u8001\u5E74", "\u5173\u6000"],
    featured: false
  },
  {
    id: "c-tang-guo",
    name: "\u5510\u679C",
    title: "LGBTQ+ \u53CB\u5584\u54A8\u8BE2\u5E08",
    specialties: ["\u6027\u522B\u8BA4\u540C", "\u6027\u5C11\u6570\u538B\u529B", "\u4EB2\u5BC6\u5173\u7CFB"],
    approach: ["\u4EBA\u672C\u4E3B\u4E49", "\u53D9\u4E8B\u7597\u6CD5"],
    region: "\u6210\u90FD",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 500,
    currency: "CNY",
    org: "\u6210\u90FD\u5F69\u8679\u5FC3\u5FC3\u7406",
    bio: "\u4E3A\u6027\u5C11\u6570\u7FA4\u4F53\u63D0\u4F9B\u53CB\u5584\u3001\u4E0D\u8BC4\u5224\u7684\u7A7A\u95F4\uFF0C\u5904\u7406\u8BA4\u540C\u4E0E\u5173\u7CFB\u8BAE\u9898\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-tang-guo",
    rating: 4.8,
    yearsExperience: 7,
    tags: ["LGBTQ+", "\u53CB\u5584"],
    featured: false
  },
  {
    id: "c-ye-zhou",
    name: "\u53F6\u821F",
    title: "\u6B63\u5FF5\u51CF\u538B\uFF08MBSR\uFF09\u5BFC\u5E08",
    specialties: ["\u7761\u7720", "\u538B\u529B", "\u6162\u6027\u75BC\u75DB\u5FC3\u7406"],
    approach: ["\u6B63\u5FF5", "ACT"],
    region: "\u8FDC\u7A0B\uFF08\u5168\u56FD\uFF09",
    remote: true,
    languages: ["\u4E2D\u6587"],
    pricePerSession: 450,
    currency: "CNY",
    org: "\u7EBF\u4E0A\u6B63\u5FF5\u7A7A\u95F4",
    bio: "\u5E26\u9886\u6B63\u5FF5\u51CF\u538B\u56E2\u4F53\u4E0E\u4E2A\u4F53\u7EC3\u4E60\uFF0C\u7F13\u89E3\u538B\u529B\u3001\u5931\u7720\u4E0E\u6162\u6027\u4E0D\u9002\u5E26\u6765\u7684\u5FC3\u7406\u8D1F\u62C5\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-ye-zhou",
    rating: 4.6,
    yearsExperience: 5,
    tags: ["\u6B63\u5FF5", "\u56E2\u4F53"],
    featured: true
  },
  {
    id: "c-mo-yu",
    name: "\u83AB\u8BED",
    title: "\u6D77\u5916\u6267\u4E1A\u5FC3\u7406\u54A8\u8BE2\u5E08\uFF08LPCC\uFF09",
    specialties: ["\u8DE8\u6587\u5316\u9002\u5E94", "\u79FB\u6C11\u538B\u529B", "\u6291\u90C1"],
    approach: ["CBT", "\u591A\u5143\u6587\u5316\u54A8\u8BE2"],
    region: "\u6D77\u5916\uFF08\u5317\u7F8E\uFF09",
    remote: true,
    languages: ["\u4E2D\u6587", "English"],
    pricePerSession: 900,
    currency: "CNY",
    org: "NorthStar Counseling",
    bio: "\u670D\u52A1\u6D77\u5916\u534E\u8BED\u7FA4\u4F53\uFF0C\u5904\u7406\u79FB\u6C11\u3001\u8DE8\u6587\u5316\u9002\u5E94\u4E0E\u60C5\u7EEA\u56F0\u6270\u3002\u672C\u5E73\u53F0\u4EC5\u505A\u4FE1\u606F\u805A\u5408\u4E0E\u8F6C\u4ECB\uFF0C\u4E0D\u6784\u6210\u8BCA\u7597\u5EFA\u8BAE\u3002",
    avatar: null,
    bookingUrl: "https://example.com/book/c-mo-yu",
    rating: 4.9,
    yearsExperience: 13,
    tags: ["\u6D77\u5916", "\u8DE8\u6587\u5316"],
    featured: false
  }
];
var reviews = [
  { id: "rv-1", counselorId: "c-lin-zhi", authorName: "\u5C0F\u9E7F", rating: 5, content: "\u6797\u8001\u5E08\u5F88\u8010\u5FC3\uFF0C\u7B2C\u4E00\u6B21\u54A8\u8BE2\u5C31\u6CA1\u90A3\u4E48\u7D27\u5F20\u4E86\u3002\u7ED9\u7684\u5C0F\u7EC3\u4E60\u56DE\u5BB6\u4E5F\u80FD\u7528\uFF0C\u60C5\u7EEA\u786E\u5B9E\u6BD4\u4E4B\u524D\u7A33\u4E86\u4E00\u4E9B\u3002", createdAt: "2026-07-08" },
  { id: "rv-2", counselorId: "c-lin-zhi", authorName: "\u963F\u54F2", rating: 4, content: "CBT \u7684\u601D\u8DEF\u8BB2\u5F97\u6E05\u695A\uFF0C\u80FD\u611F\u89C9\u5230\u662F\u5728\u7528\u65B9\u6CD5\u5E2E\u6211\uFF0C\u800C\u4E0D\u662F\u53EA\u542C\u6211\u503E\u8BC9\u3002\u8282\u594F\u7A0D\u5FEB\uFF0C\u4F46\u603B\u4F53\u6709\u7528\u3002", createdAt: "2026-07-12" },
  { id: "rv-3", counselorId: "c-su-wan", authorName: "\u665A\u98CE", rating: 5, content: "\u548C\u4F34\u4FA3\u4E00\u8D77\u505A\u7684\u51E0\u6B21\u54A8\u8BE2\uFF0C\u6C9F\u901A\u65B9\u5F0F\u771F\u7684\u6709\u53D8\u5316\u3002\u82CF\u8001\u5E08\u4E0D\u7AD9\u961F\uFF0C\u5E2E\u6211\u4EEC\u770B\u5230\u5F7C\u6B64\u7684\u5FAA\u73AF\u3002", createdAt: "2026-07-05" },
  { id: "rv-4", counselorId: "c-su-wan", authorName: "Mia", rating: 5, content: "\u672C\u6765\u662F\u62B1\u7740\u8BD5\u8BD5\u770B\u7684\u5FC3\u6001\uFF0C\u7ED3\u679C\u7B2C\u4E00\u6B21\u5C31\u804A\u5230\u4E86\u70B9\u4E0A\u3002\u5BF9\u4EB2\u5BC6\u5173\u7CFB\u7684\u7406\u89E3\u6253\u5F00\u4E86\u65B0\u89D2\u5EA6\u3002", createdAt: "2026-07-15" },
  { id: "rv-5", counselorId: "c-chen-yu", authorName: "\u533F\u540D", rating: 4, content: "\u521B\u4F24\u7684\u90E8\u5206\u8BB2\u5F97\u5F88\u8C28\u614E\uFF0C\u6709\u7A33\u5B9A\u5316\u7684\u6B65\u9AA4\uFF0C\u8BA9\u6211\u89C9\u5F97\u5B89\u5168\u3002\u8282\u594F\u6162\u4F46\u8E0F\u5B9E\u3002", createdAt: "2026-07-09" },
  { id: "rv-6", counselorId: "c-he-chuan", authorName: "\u52A0\u73ED\u72D7", rating: 5, content: "\u9488\u5BF9\u804C\u4E1A\u5026\u6020\u7ED9\u7684\u5EFA\u8BAE\u5F88\u843D\u5730\uFF0C\u6B63\u5FF5\u7EC3\u4E60\u575A\u6301\u4E24\u5468\uFF0C\u5165\u7761\u5BB9\u6613\u4E86\u4E9B\u3002\u9002\u5408\u9AD8\u538B\u6253\u5DE5\u4EBA\u7684\u8282\u594F\u3002", createdAt: "2026-07-03" },
  { id: "rv-7", counselorId: "c-he-chuan", authorName: "\u5C0F\u6EE1", rating: 4, content: "\u4F55\u8001\u5E08\u5BF9\u7761\u7720\u548C\u538B\u529B\u7684\u62C6\u89E3\u5F88\u4E13\u4E1A\uFF0C\u4E0D\u4F1A\u7A7A\u8C08\u3002\u5E0C\u671B\u540E\u7EED\u80FD\u6709\u7EBF\u4E0A\u7684\u56E2\u4F53\u3002", createdAt: "2026-07-18" },
  { id: "rv-8", counselorId: "c-jiang-lin", authorName: "\u6F02\u6D41\u74F6", rating: 5, content: "\u957F\u7A0B\u505A\u4E86\u4E00\u6BB5\u65F6\u95F4\uFF0C\u5BF9\u81EA\u5DF1\u5F88\u591A\u6A21\u5F0F\u7406\u89E3\u6DF1\u4E86\u3002\u6C5F\u8001\u5E08\u8BDD\u4E0D\u591A\u4F46\u6BCF\u6B21\u90FD\u80FD\u63A5\u4F4F\u3002", createdAt: "2026-06-28" },
  { id: "rv-9", counselorId: "c-wei-an", authorName: "\u8001\u5468", rating: 5, content: "\u548C\u59BB\u5B50\u4E00\u8D77\u6765\u7684\uFF0C\u97E6\u8001\u5E08\u5E2E\u6211\u4EEC\u628A\u5435\u4E86\u591A\u5E74\u7684\u65E7\u8D26\u6362\u4E2A\u65B9\u5F0F\u8BF4\u4E86\u51FA\u6765\uFF0C\u6C1B\u56F4\u677E\u4E86\u5F88\u591A\u3002", createdAt: "2026-07-01" },
  { id: "rv-10", counselorId: "c-ye-zhou", authorName: "\u6A59\u5B50", rating: 5, content: "\u6B63\u5FF5\u51CF\u538B\u7684\u56E2\u4F53\u4F53\u9A8C\u5F88\u597D\uFF0C\u53F6\u8001\u5E08\u5F15\u5BFC\u5F88\u7A33\uFF0C\u7126\u8651\u6765\u7684\u65F6\u5019\u6709\u4E86\u53EF\u7528\u7684\u5DE5\u5177\u3002", createdAt: "2026-07-11" },
  { id: "rv-11", counselorId: "c-ye-zhou", authorName: "\u591C\u732B\u5B50", rating: 4, content: "\u7761\u7720\u76F8\u5173\u7684\u7EC3\u4E60\u5BF9\u6211\u5E2E\u52A9\u660E\u663E\uFF0C\u767D\u5929\u6CA1\u90A3\u4E48\u5BB9\u6613\u70B8\u4E86\u3002\u4E2A\u522B\u8BED\u97F3\u5F15\u5BFC\u7A0D\u957F\u3002", createdAt: "2026-07-19" },
  { id: "rv-12", counselorId: "c-mo-yu", authorName: "Lin", rating: 5, content: "\u5728\u6D77\u5916\u627E\u534E\u8BED\u54A8\u8BE2\u5E08\u4E0D\u5BB9\u6613\uFF0C\u83AB\u8001\u5E08\u61C2\u8DE8\u6587\u5316\u90A3\u90E8\u5206\u538B\u529B\uFF0C\u804A\u8D77\u6765\u4E0D\u7528\u53CD\u590D\u89E3\u91CA\u80CC\u666F\u3002", createdAt: "2026-07-07" },
  { id: "rv-13", counselorId: "c-tang-guo", authorName: "\u5F69\u8679", rating: 5, content: "\u4F5C\u4E3A\u6027\u5C11\u6570\uFF0C\u7B2C\u4E00\u6B21\u9047\u5230\u4E0D\u8BC4\u5224\u7684\u7A7A\u95F4\u3002\u5510\u8001\u5E08\u5F88\u6E29\u67D4\u4E5F\u5F88\u4E13\u4E1A\uFF0C\u63A8\u8350\u7ED9\u9700\u8981\u7684\u670B\u53CB\u3002", createdAt: "2026-07-14" },
  { id: "rv-14", counselorId: "c-luo-yu", authorName: "\u8C46\u8C46\u5988", rating: 5, content: "\u5B69\u5B50\u9752\u6625\u671F\u7684\u6C9F\u901A\u95EE\u9898\uFF0C\u7F57\u8001\u5E08\u7528\u6E38\u620F\u548C\u6E29\u548C\u7684\u65B9\u5F0F\uFF0C\u5B69\u5B50\u613F\u610F\u5F00\u53E3\u4E86\u3002", createdAt: "2026-07-16" }
];

// backend/scripts/preview-server.ts
// 注入 createdAt（按数组顺序给出稳定梯度，使「最新收录」排序可用；mock 无真实时间字段）
var RES_BASE_TS = Date.parse("2026-06-01T00:00:00Z");
var resources2 = resources.map((r, i) => ({
  id: "r-" + (String(r.name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || String(i + 1)),
  createdAt: new Date(RES_BASE_TS + (resources.length - i) * 864e5).toISOString().slice(0, 10),
  ...r
}));
var PORT = Number(process.env.PORT || 3001);
var reviewStore = reviews.map((r) => ({ ...r }));
var sessionUser = null;
var now = Date.now();
var submissionStore = [
  {
    id: "sub-seed-1",
    kind: "resource",
    name: "\u6B63\u5FF5\u51A5\u60F3\u5C0F\u5DE5\u5177",
    url: "https://mindful-example.com",
    type: "SAAS",
    specialty: "",
    description: "\u4E00\u6B3E\u5E2E\u52A9\u7528\u6237\u5728\u788E\u7247\u65F6\u95F4\u8FDB\u884C\u6B63\u5FF5\u547C\u5438\u7EC3\u4E60\u7684\u8F7B\u91CF\u5DE5\u5177\u3002",
    tags: ["\u79D1\u666E", "\u51A5\u60F3", "\u81EA\u52A9\u5DE5\u5177"],
    country: "\u4E2D\u56FD",
    submitterEmail: "demo@psychhub.cn",
    status: "pending",
    submittedAt: new Date(now - 2 * 864e5).toISOString()
  },
  {
    id: "sub-seed-2",
    kind: "counselor",
    name: "\u674E\u9759 \xB7 \u5BB6\u5EAD\u6CBB\u7597\u5E08",
    url: "https://example-counselor.com",
    type: "",
    specialty: "\u5BB6\u5EAD\u6CBB\u7597",
    description: "\u4E13\u6CE8\u5BB6\u5EAD\u5173\u7CFB\u4E0E\u4EB2\u5B50\u6C9F\u901A\uFF0C10 \u5E74\u4ECE\u4E1A\u7ECF\u9A8C\u3002",
    tags: ["\u5BB6\u5EAD\u6CBB\u7597", "\u4EB2\u5B50\u5173\u7CFB"],
    country: "\u4E2D\u56FD",
    submitterEmail: "demo@psychhub.cn",
    status: "approved",
    submittedAt: new Date(now - 9 * 864e5).toISOString()
  },
  {
    id: "sub-seed-3",
    kind: "resource",
    name: "\u67D0\u5FC3\u7406\u6D4B\u8BC4\u5E73\u53F0",
    url: "https://example-assess.com",
    type: "WEBSITE",
    specialty: "",
    description: "\u63D0\u4F9B\u591A\u79CD\u5728\u7EBF\u5FC3\u7406\u6D4B\u8BC4\u91CF\u8868\uFF0C\u8986\u76D6\u60C5\u7EEA\u3001\u538B\u529B\u3001\u7761\u7720\u7B49\u7EF4\u5EA6\u3002",
    tags: ["\u6D4B\u8BC4"],
    country: "\u4E2D\u56FD",
    submitterEmail: "demo@psychhub.cn",
    status: "rejected",
    submittedAt: new Date(now - 16 * 864e5).toISOString()
  }
];
function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "no-store"
  });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (c) => data += c);
    req.on("end", () => {
      try {
        resolve(data ? JSON.parse(data) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}
function filterResources(params) {
  const q = (params.get("q") || "").toLowerCase();
  const type = params.get("type") || "";
  const country = params.get("country") || "";
  const language = params.get("language") || "";
  const tag = params.get("tag") || "";
  return resources2.filter((r) => type ? r.type === type : true).filter((r) => country ? r.country === country : true).filter((r) => language ? r.language === language : true).filter((r) => tag ? r.tags.includes(tag) : true).filter((r) => {
    if (!q) return true;
    return r.name.toLowerCase().includes(q) || (r.description || "").toLowerCase().includes(q) || r.tags.some((t) => t.toLowerCase().includes(q));
  }).sort((a, b) => Number(!!b.featured) - Number(!!a.featured));
}
function filterHelplines(params) {
  const country = params.get("country") || "";
  const language = params.get("language") || "";
  const category = params.get("category") || "";
  const q = (params.get("q") || "").toLowerCase();
  return helplines.filter((h) => country ? h.country === country : true).filter((h) => language ? h.language === language : true).filter((h) => category ? h.category === category : true).filter(
    (h) => !q ? true : (h.name || "").toLowerCase().includes(q) || (h.description || "").toLowerCase().includes(q)
  );
}
var server = import_node_http.default.createServer(async (req, res) => {
  const url = new import_node_url.URL(req.url || "/", `http://localhost:${PORT}`);
  const p = url.pathname;
  const params = url.searchParams;
  const method = req.method || "GET";
  try {
    if (p === "/api/resources" || p === "/api/resources/") {
      return send(res, 200, filterResources(params));
    }
    if (p === "/api/resources/featured") {
      return send(res, 200, resources2.filter((r) => r.featured));
    }
    const resMatch = p.match(/^\/api\/resources\/([^/]+)$/);
    if (resMatch) {
      const key = decodeURIComponent(resMatch[1]);
      const item = resources2.find((r) => r.id === key || r.name === key);
      return item ? send(res, 200, item) : send(res, 404, { error: "not found" });
    }
    if (p === "/api/helplines" || p === "/api/helplines/") {
      return send(res, 200, filterHelplines(params));
    }
    if (p === "/api/assessments" || p === "/api/assessments/") {
      const q = (params.get("q") || "").toLowerCase();
      const type = params.get("type") || "";
      const list = assessments.filter((a) => type ? a.type === type : true).filter(
        (a) => !q ? true : (a.title || "").toLowerCase().includes(q) || (a.description || "").toLowerCase().includes(q)
      ).map(({ questions, interpretation, ...rest }) => rest);
      return send(res, 200, list);
    }
    const assMatch = p.match(/^\/api\/assessments\/([^/]+)$/);
    if (assMatch) {
      const item = assessments.find((a) => a.slug === assMatch[1]);
      return item ? send(res, 200, item) : send(res, 404, { error: "not found" });
    }
    if (p === "/api/articles" || p === "/api/articles/") {
      const category = params.get("category") || "";
      const q = (params.get("q") || "").toLowerCase();
      const list = articles.filter((a) => category ? a.category === category : true).filter(
        (a) => !q ? true : (a.title || "").toLowerCase().includes(q) || (a.excerpt || "").toLowerCase().includes(q) || (a.content || "").toLowerCase().includes(q) || (a.tags || []).some((t) => t.toLowerCase().includes(q))
      );
      return send(res, 200, list);
    }
    const artMatch = p.match(/^\/api\/articles\/([^/]+)$/);
    if (artMatch) {
      const item = articles.find((a) => a.slug === artMatch[1]);
      return item ? send(res, 200, item) : send(res, 404, { error: "not found" });
    }
    if (p === "/api/counselors" || p === "/api/counselors/") {
      const specialty = params.get("specialty") || "";
      const region = params.get("region") || "";
      const maxPrice = params.get("maxPrice") ? Number(params.get("maxPrice")) : null;
      const remoteOnly = params.get("remote") === "1";
      const q = (params.get("q") || "").toLowerCase();
      const list = counselors.filter((c) => specialty ? c.specialties.includes(specialty) : true).filter((c) => region ? c.region === region : true).filter((c) => maxPrice != null ? (c.pricePerSession ?? Infinity) <= maxPrice : true).filter((c) => remoteOnly ? c.remote : true).filter(
        (c) => !q ? true : c.name.toLowerCase().includes(q) || c.specialties.some((s) => s.toLowerCase().includes(q)) || (c.bio || "").toLowerCase().includes(q)
      ).sort((a, b) => Number(!!b.featured) - Number(!!a.featured));
      return send(res, 200, list);
    }
    const couMatch = p.match(/^\/api\/counselors\/([^/]+)$/);
    if (couMatch) {
      const item = counselors.find((c) => c.id === couMatch[1]);
      return item ? send(res, 200, item) : send(res, 404, { error: "not found" });
    }
    const revListMatch = p.match(/^\/api\/counselors\/([^/]+)\/reviews$/);
    if (revListMatch) {
      const cid = revListMatch[1];
      const list = reviewStore.filter((r) => r.counselorId === cid).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      return send(res, 200, list);
    }
    if (p === "/api/reviews" || p === "/api/reviews/") {
      if (method === "POST") {
        if (!sessionUser) return send(res, 401, { error: "\u8BF7\u5148\u767B\u5F55\u540E\u518D\u53D1\u8868\u8BC4\u4EF7" });
        const body = await readBody(req);
        const counselorId = (body.counselorId || "").toString();
        const rating = Number(body.rating);
        const content = (body.content || "").toString().trim();
        if (!counselors.find((c) => c.id === counselorId)) {
          return send(res, 404, { error: "\u54A8\u8BE2\u5E08\u4E0D\u5B58\u5728" });
        }
        if (!(rating >= 1 && rating <= 5)) return send(res, 400, { error: "\u8BC4\u5206\u9700\u4E3A 1-5 \u7684\u6574\u6570" });
        if (content.length < 5) return send(res, 400, { error: "\u8BC4\u4EF7\u5185\u5BB9\u81F3\u5C11 5 \u4E2A\u5B57" });
        const review = {
          id: "r-" + Date.now(),
          counselorId,
          authorName: sessionUser.name,
          authorId: sessionUser.id,
          rating,
          content,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        reviewStore.unshift(review);
        return send(res, 200, { review });
      }
      const authorId = params.get("authorId") || "";
      let list = authorId ? reviewStore.filter((r) => r.authorId === authorId) : reviewStore.slice();
      list = list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      const withName = list.map((r) => ({
        ...r,
        counselorName: counselors.find((c) => c.id === r.counselorId)?.name ?? "\u672A\u77E5\u54A8\u8BE2\u5E08"
      }));
      return send(res, 200, withName);
    }
    if (p === "/api/auth/me") {
      if (method === "POST") {
        sessionUser = null;
        return send(res, 200, { user: null });
      }
      return send(res, 200, { user: sessionUser });
    }
    if (p === "/api/auth/login") {
      const body = await readBody(req);
      const email = (body.email || "").toString();
      if (!email) return send(res, 400, { error: "\u90AE\u7BB1\u5FC5\u586B" });
      const name = (body.name || sessionUser?.name || email.split("@")[0]).toString();
      sessionUser = { id: sessionUser?.id || "u-" + Date.now(), name, email };
      return send(res, 200, { user: sessionUser });
    }
    if (p === "/api/auth/register") {
      const body = await readBody(req);
      const email = (body.email || "").toString();
      const name = (body.name || email.split("@")[0]).toString();
      if (!email) return send(res, 400, { error: "\u90AE\u7BB1\u5FC5\u586B" });
      sessionUser = { id: "u-" + Date.now(), name, email };
      return send(res, 200, { user: sessionUser });
    }
    if (p === "/api/submissions" || p === "/api/submissions/") {
      if (method === "POST") {
        const body = await readBody(req);
        const kind = (body.kind || "").toString();
        const name = (body.name || "").toString().trim();
        const url2 = (body.url || "").toString().trim();
        const description = (body.description || "").toString().trim();
        const email = (body.submitterEmail || "").toString().trim();
        if (kind !== "resource" && kind !== "counselor") {
          return send(res, 400, { error: "\u8BF7\u9009\u62E9\u6536\u5F55\u7C7B\u578B\uFF08\u8D44\u6E90\u6216\u54A8\u8BE2\u5E08\uFF09" });
        }
        if (name.length < 2) return send(res, 400, { error: "\u540D\u79F0\u81F3\u5C11 2 \u4E2A\u5B57" });
        if (!/^https?:\/\/.+/.test(url2)) {
          return send(res, 400, { error: "\u8BF7\u8F93\u5165\u6709\u6548\u7684\u7F51\u5740\uFF08\u4EE5 http:// \u6216 https:// \u5F00\u5934\uFF09" });
        }
        if (description && description.length < 5) {
          return send(res, 400, { error: "\u63CF\u8FF0\u81F3\u5C11 5 \u4E2A\u5B57\uFF08\u6216\u7559\u7A7A\uFF09" });
        }
        if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
          return send(res, 400, { error: "\u90AE\u7BB1\u683C\u5F0F\u4E0D\u6B63\u786E" });
        }
        const submission = {
          id: "sub-" + Date.now(),
          kind,
          name,
          url: url2,
          type: (body.type || "").toString(),
          specialty: (body.specialty || "").toString(),
          description,
          tags: (body.tags || "").toString().split(",").map((t) => t.trim()).filter(Boolean),
          country: (body.country || "").toString(),
          submitterEmail: email,
          status: "pending",
          submittedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        submissionStore.unshift(submission);
        return send(res, 200, { submission });
      }
      const mine = params.get("mine") === "1";
      if (mine) {
        const email = params.get("email") || sessionUser?.email || "";
        const list = email ? submissionStore.filter((s) => s.submitterEmail === email) : [];
        return send(res, 200, list);
      }
      return send(res, 200, submissionStore.slice());
    }
    if (p === "/api/health") {
      return send(res, 200, { ok: true, source: "preview-data-server" });
    }
    return send(res, 404, { error: "route not found" });
  } catch (e) {
    return send(res, 500, { error: String(e) });
  }
});
server.listen(PORT, () => {
  console.log(`\u672C\u5730\u9884\u89C8\u6570\u636E\u670D\u52A1\u5DF2\u542F\u52A8: http://localhost:${PORT}`);
  console.log(
    `  \u8D44\u6E90 ${resources2.length} \u6761 / \u6C42\u52A9 ${helplines.length} \u6761 / \u6D4B\u8BC4 ${assessments.length} \u4E2A / \u54A8\u8BE2\u5E08 ${counselors.length} \u4F4D / \u8BC4\u4EF7 ${reviewStore.length} \u6761`
  );
});
