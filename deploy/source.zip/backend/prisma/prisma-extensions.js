"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.asArray = void 0;
exports.serializeForDb = serializeForDb;
exports.deserializeFromDb = deserializeFromDb;
exports.createPrismaClient = createPrismaClient;
const client_1 = require("@prisma/client");
const db_array_util_1 = require("../src/common/db-array.util");
Object.defineProperty(exports, "asArray", { enumerable: true, get: function () { return db_array_util_1.asArray; } });
const ARRAY_FIELDS = new Set(['tags', 'specialties', 'approach', 'languages']);
const JSON_FIELDS = new Set(['questions', 'interpretation']);
const DELIM = db_array_util_1.DB_ARRAY_DELIM;
function isPlainObject(v) {
    return (v != null &&
        typeof v === 'object' &&
        !Array.isArray(v) &&
        !(v instanceof Date));
}
function serializeForDb(node) {
    if (Array.isArray(node))
        return node.map(serializeForDb);
    if (isPlainObject(node)) {
        const out = {};
        for (const [k, v] of Object.entries(node)) {
            if (ARRAY_FIELDS.has(k) && Array.isArray(v)) {
                out[k] = DELIM + v.join(DELIM) + DELIM;
            }
            else if (JSON_FIELDS.has(k) && isPlainObject(v)) {
                out[k] = JSON.stringify(v);
            }
            else if (v && typeof v === 'object' && !(v instanceof Date)) {
                out[k] = serializeForDb(v);
            }
            else {
                out[k] = v;
            }
        }
        return out;
    }
    return node;
}
function deserializeFromDb(node) {
    if (Array.isArray(node))
        return node.map(deserializeFromDb);
    if (isPlainObject(node)) {
        const out = {};
        for (const [k, v] of Object.entries(node)) {
            if (ARRAY_FIELDS.has(k) && typeof v === 'string') {
                out[k] = v.split(DELIM).filter(Boolean);
            }
            else if (JSON_FIELDS.has(k) && typeof v === 'string') {
                try {
                    out[k] = JSON.parse(v);
                }
                catch {
                    out[k] = v;
                }
            }
            else if (v && typeof v === 'object' && !(v instanceof Date)) {
                out[k] = deserializeFromDb(v);
            }
            else {
                out[k] = v;
            }
        }
        return out;
    }
    return node;
}
function transformArgs(args) {
    if (!args || typeof args !== 'object')
        return args;
    const out = { ...args };
    for (const key of ['data', 'create', 'update']) {
        if (out[key] !== undefined)
            out[key] = serializeForDb(out[key]);
    }
    return out;
}
function createPrismaClient() {
    return new client_1.PrismaClient().$extends({
        query: {
            $allOperations({ args, query }) {
                const newArgs = transformArgs(args);
                return Promise.resolve(query(newArgs)).then((res) => deserializeFromDb(res));
            },
        },
    });
}
//# sourceMappingURL=prisma-extensions.js.map