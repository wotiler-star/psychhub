import { PrismaClient } from '@prisma/client';
import { asArray } from '../src/common/db-array.util';
export { asArray };
export declare function serializeForDb(node: any): any;
export declare function deserializeFromDb(node: any): any;
export declare function createPrismaClient(): PrismaClient;
